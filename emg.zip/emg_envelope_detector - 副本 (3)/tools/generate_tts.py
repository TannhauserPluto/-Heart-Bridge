#!/usr/bin/env python3
"""Generate and validate all offline HeartBridge voice prompts.

Development-time dependencies are installed under tools/.packages so the
firmware remains entirely offline.  The current NeedCatalog and timing
constants are parsed and validated on every run.
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import json
import math
import re
import shutil
import sys
import wave
from array import array
from dataclasses import asdict, dataclass
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


ROOT = Path(__file__).resolve().parents[1]
LOCAL_PACKAGES = ROOT / "tools" / ".packages"
if LOCAL_PACKAGES.is_dir():
    sys.path.insert(0, str(LOCAL_PACKAGES))

try:
    import edge_tts
    import miniaudio
except ImportError as exc:  # pragma: no cover - actionable environment error
    raise SystemExit(
        "Missing tools. Run: python -m pip install --target "
        "tools/.packages edge-tts miniaudio"
    ) from exc


VOICE = "zh-CN-XiaoxiaoNeural"
PITCH = "-8Hz"
DEFAULT_RATE = "-5%"
RATE_CANDIDATES = ("-5%", "+0%", "+5%", "+10%", "+15%", "+20%", "+25%", "+30%")
SAMPLE_RATE = 16000
CHANNELS = 1
SAMPLE_WIDTH = 2
SAFETY_MARGIN_MS = 300
TARGET_PEAK = 0.78

SOURCE_DIR = ROOT / "audio" / "source"
WAV_DIR = ROOT / "audio" / "wav"
MANIFEST_CSV = ROOT / "audio" / "audio_manifest.csv"
MANIFEST_JSON = ROOT / "audio" / "audio_manifest.json"
DEPLOY_DIR = ROOT / "data" / "voice"


@dataclass(frozen=True)
class PromptSpec:
    id: str
    state: str
    screen_text: str
    spoken_text: str
    filename: str
    duration_key: str | None


@dataclass
class ManifestRow:
    id: str
    state: str
    screen_text: str
    spoken_text: str
    filename: str
    voice: str
    rate: str
    pitch: str
    initial_duration_ms: int
    duration_ms: int
    screen_duration_ms: int | None
    margin_ms: int | None
    sample_rate: int
    channels: int
    bit_depth: int
    size_bytes: int
    adjusted_for_duration: bool
    status: str


NEED_PROMPTS = {
    "WATER": ("water", "您需要喝水吗？", "您选择了喝水，请确认。"),
    "PAIN": ("pain", "您感到疼痛吗？", "您表示感到疼痛，请确认。"),
    "TURN_OVER": ("turn_over", "您需要翻身吗？", "您选择了翻身，请确认。"),
    "TOILET": ("toilet", "您需要上厕所吗？", "您选择了上厕所，请确认。"),
    "COLD": ("cold", "您觉得冷吗？", "您选择了冷，请确认。"),
    "HOT": ("hot", "您觉得热吗？", "您选择了热，请确认。"),
    "CALL_FAMILY": ("call_family", "您需要呼叫家属吗？", "您选择了呼叫家属，请确认。"),
    "CALL_DOCTOR": ("call_doctor", "您需要呼叫医生吗？", "您选择了呼叫医生，请确认。"),
    "REST": ("rest", "您需要休息吗？", "您选择了休息，请确认。"),
    "OTHER": ("other", "您有其他需求吗？", "您选择了其他需求，请确认。"),
}


def parse_need_catalog() -> list[tuple[str, str, str]]:
    source = (ROOT / "src" / "Interaction" / "NeedCatalog.cpp").read_text(encoding="utf-8")
    rows = re.findall(
        r'\{NeedId::([A-Z_]+),\s*"([A-Z_]+)",\s*"([^"]+)"\}', source
    )
    if not rows:
        raise RuntimeError("NeedCatalog parser found no needs")
    actual_keys = [row[0] for row in rows]
    expected_keys = list(NEED_PROMPTS)
    if actual_keys != expected_keys:
        raise RuntimeError(
            f"NeedCatalog changed. Actual={actual_keys}, prompt map={expected_keys}"
        )
    return rows


def parse_screen_durations() -> dict[str, int]:
    source = (ROOT / "src" / "Core" / "Config.h").read_text(encoding="utf-8")
    values = {
        name: int(value)
        for name, value in re.findall(
            r"constexpr\s+uint32_t\s+(k\w+(?:Duration|Timeout|Interval)Ms)\s*=\s*(\d+)\s*;",
            source,
        )
    }
    required = {
        "kNeedScanIntervalMs",
        "kPromptTimeoutMs",
        "kConfirmationTimeoutMs",
        "kRequestSentDurationMs",
        "kCancelledScreenDurationMs",
        "kCallingFamilyDurationMs",
    }
    missing = required - values.keys()
    if missing:
        raise RuntimeError(f"Missing timing constants: {sorted(missing)}")
    return values


def validate_screen_text(specs: list[PromptSpec]) -> None:
    display = (ROOT / "src" / "Display" / "MainDisplay" / "MainDisplay.cpp").read_text(
        encoding="utf-8"
    )
    required_literals = {
        "请问是否有需求",
        "请确认",
        "您选择",
        "正在呼叫家属",
        "请稍候",
        "家属已收到请求",
        "已取消",
        "系统暂时不可用",
    }
    missing = sorted(text for text in required_literals if text not in display)
    if missing:
        raise RuntimeError(f"MainDisplay text changed; missing {missing}")
    if len(specs) != 25:
        raise RuntimeError(f"Expected 25 voice prompts, found {len(specs)}")


def build_specs() -> list[PromptSpec]:
    needs = parse_need_catalog()
    specs = [
        PromptSpec(
            "ask_need",
            "ASK_HAS_NEED",
            "请问是否有需求",
            "请问是否有需求？",
            "ask_need.wav",
            "kPromptTimeoutMs",
        )
    ]
    for need_id, _id_name, screen_text in needs:
        stem, question, _confirmation = NEED_PROMPTS[need_id]
        specs.append(
            PromptSpec(
                f"need_{stem}",
                f"SCAN_NEEDS/{need_id}",
                screen_text,
                question,
                f"need_{stem}.wav",
                "kNeedScanIntervalMs",
            )
        )
    for need_id, _id_name, screen_text in needs:
        stem, _question, confirmation = NEED_PROMPTS[need_id]
        specs.append(
            PromptSpec(
                f"confirm_{stem}",
                f"CONFIRM_NEED/{need_id}",
                f"请确认 / 您选择 / {screen_text}",
                confirmation,
                f"confirm_{stem}.wav",
                "kConfirmationTimeoutMs",
            )
        )
    specs.extend(
        [
            PromptSpec(
                "calling_family",
                "CALLING_FAMILY",
                "正在呼叫家属 / 请稍候",
                "正在呼叫家属。",
                "calling_family.wav",
                "kCallingFamilyDurationMs",
            ),
            PromptSpec(
                "request_sent",
                "REQUEST_SENT",
                "请求已发送 / 家属已收到请求 / 请稍候",
                "家属已收到请求，请稍候。",
                "request_sent.wav",
                "kRequestSentDurationMs",
            ),
            PromptSpec(
                "cancelled",
                "CANCELLED",
                "已取消 / 系统将返回待机",
                "已取消。",
                "cancelled.wav",
                "kCancelledScreenDurationMs",
            ),
            PromptSpec(
                "error",
                "ERROR_STATE",
                "系统暂时不可用",
                "系统暂时不可用。",
                "error.wav",
                None,
            ),
        ]
    )
    validate_screen_text(specs)
    return specs


def trim_normalize_and_write(mp3_path: Path, wav_path: Path) -> int:
    decoded = miniaudio.decode_file(
        str(mp3_path),
        output_format=miniaudio.SampleFormat.SIGNED16,
        nchannels=CHANNELS,
        sample_rate=SAMPLE_RATE,
    )
    samples = array("h", decoded.samples)
    if not samples:
        raise RuntimeError(f"Decoded no samples from {mp3_path}")

    peak = max(abs(value) for value in samples)
    threshold = max(220, int(peak * 0.012))
    window = max(1, SAMPLE_RATE // 100)  # 10 ms
    active_windows: list[int] = []
    for start in range(0, len(samples), window):
        chunk = samples[start : start + window]
        rms = math.sqrt(sum(value * value for value in chunk) / len(chunk))
        if rms >= threshold:
            active_windows.append(start)
    if active_windows:
        padding = int(SAMPLE_RATE * 0.04)
        first = max(0, active_windows[0] - padding)
        last = min(len(samples), active_windows[-1] + window + padding)
        samples = samples[first:last]

    peak = max(abs(value) for value in samples)
    target = int(32767 * TARGET_PEAK)
    gain = min(4.0, target / peak) if peak else 1.0
    if abs(gain - 1.0) > 0.001:
        samples = array(
            "h",
            (max(-32768, min(32767, int(round(value * gain)))) for value in samples),
        )

    fade_samples = min(len(samples) // 2, int(SAMPLE_RATE * 0.008))
    for index in range(fade_samples):
        factor = index / max(1, fade_samples)
        samples[index] = int(samples[index] * factor)
        samples[-1 - index] = int(samples[-1 - index] * factor)

    wav_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(wav_path), "wb") as wav:
        wav.setnchannels(CHANNELS)
        wav.setsampwidth(SAMPLE_WIDTH)
        wav.setframerate(SAMPLE_RATE)
        wav.writeframes(samples.tobytes())
    return round(len(samples) * 1000 / SAMPLE_RATE)


def inspect_wav(path: Path) -> tuple[int, int, int, int, int]:
    with wave.open(str(path), "rb") as wav:
        channels = wav.getnchannels()
        sample_width = wav.getsampwidth()
        sample_rate = wav.getframerate()
        frames = wav.getnframes()
        compression = wav.getcomptype()
    if (channels, sample_width, sample_rate, compression) != (
        CHANNELS,
        SAMPLE_WIDTH,
        SAMPLE_RATE,
        "NONE",
    ):
        raise RuntimeError(
            f"Invalid WAV {path}: channels={channels}, width={sample_width}, "
            f"rate={sample_rate}, compression={compression}"
        )
    duration_ms = round(frames * 1000 / sample_rate)
    return duration_ms, sample_rate, channels, sample_width * 8, path.stat().st_size


async def synthesize(text: str, output: Path, rate: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    communicate = edge_tts.Communicate(text, VOICE, rate=rate, pitch=PITCH)
    await communicate.save(str(output))


async def generate_prompt(
    spec: PromptSpec,
    durations: dict[str, int],
    skip_tts: bool,
    previous: dict[str, object] | None,
) -> ManifestRow:
    source_path = SOURCE_DIR / f"{spec.id}.mp3"
    wav_path = WAV_DIR / spec.filename
    screen_ms = durations[spec.duration_key] if spec.duration_key else None
    final_rate = DEFAULT_RATE
    initial_duration = 0
    duration_ms = 0

    if skip_tts:
        if not source_path.exists():
            raise RuntimeError(f"Missing source for --skip-tts: {source_path}")
        final_rate = str(previous["rate"]) if previous else DEFAULT_RATE
        duration_ms = trim_normalize_and_write(source_path, wav_path)
        initial_duration = (
            int(previous["initial_duration_ms"])
            if previous and previous.get("initial_duration_ms")
            else duration_ms
        )
    else:
        for attempt, rate in enumerate(RATE_CANDIDATES):
            await synthesize(spec.spoken_text, source_path, rate)
            duration_ms = trim_normalize_and_write(source_path, wav_path)
            if attempt == 0:
                initial_duration = duration_ms
            final_rate = rate
            if screen_ms is None or duration_ms <= screen_ms - SAFETY_MARGIN_MS:
                break

    duration_ms, sample_rate, channels, bit_depth, size_bytes = inspect_wav(wav_path)
    margin_ms = None if screen_ms is None else screen_ms - duration_ms
    if screen_ms is None:
        status = "PASS_UNBOUNDED"
    elif margin_ms is not None and margin_ms >= SAFETY_MARGIN_MS:
        status = "PASS"
    else:
        status = "AUDIO_DURATION_CONFLICT"
    return ManifestRow(
        id=spec.id,
        state=spec.state,
        screen_text=spec.screen_text,
        spoken_text=spec.spoken_text,
        filename=spec.filename,
        voice=VOICE,
        rate=final_rate,
        pitch=PITCH,
        initial_duration_ms=initial_duration,
        duration_ms=duration_ms,
        screen_duration_ms=screen_ms,
        margin_ms=margin_ms,
        sample_rate=sample_rate,
        channels=channels,
        bit_depth=bit_depth,
        size_bytes=size_bytes,
        adjusted_for_duration=final_rate != DEFAULT_RATE,
        status=status,
    )


def write_manifest(rows: list[ManifestRow]) -> None:
    MANIFEST_CSV.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(asdict(rows[0]).keys())
    with MANIFEST_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)
    MANIFEST_JSON.write_text(
        json.dumps([asdict(row) for row in rows], ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def sync_deployment_assets(rows: list[ManifestRow]) -> None:
    DEPLOY_DIR.mkdir(parents=True, exist_ok=True)
    expected = {row.filename for row in rows}
    for existing in DEPLOY_DIR.glob("*.wav"):
        if existing.name not in expected:
            existing.unlink()
    for row in rows:
        shutil.copy2(WAV_DIR / row.filename, DEPLOY_DIR / row.filename)


async def async_main(skip_tts: bool) -> int:
    specs = build_specs()
    durations = parse_screen_durations()
    SOURCE_DIR.mkdir(parents=True, exist_ok=True)
    WAV_DIR.mkdir(parents=True, exist_ok=True)
    previous_rows: dict[str, dict[str, object]] = {}
    if skip_tts and MANIFEST_JSON.exists():
        previous_rows = {
            row["id"]: row
            for row in json.loads(MANIFEST_JSON.read_text(encoding="utf-8"))
        }

    rows: list[ManifestRow] = []
    for index, spec in enumerate(specs, start=1):
        print(f"[{index:02d}/{len(specs)}] {spec.id}: {spec.spoken_text}", flush=True)
        row = await generate_prompt(
            spec, durations, skip_tts, previous_rows.get(spec.id)
        )
        rows.append(row)
        margin = "unbounded" if row.margin_ms is None else f"{row.margin_ms} ms"
        print(
            f"  {row.duration_ms} ms, screen={row.screen_duration_ms}, "
            f"margin={margin}, rate={row.rate}, {row.status}",
            flush=True,
        )

    write_manifest(rows)
    sync_deployment_assets(rows)
    total_size = sum(row.size_bytes for row in rows)
    conflicts = [row.id for row in rows if row.status == "AUDIO_DURATION_CONFLICT"]
    print(f"Generated {len(rows)} WAV files, total {total_size} bytes")
    print(f"Manifest: {MANIFEST_CSV}")
    print(f"LittleFS assets: {DEPLOY_DIR}")
    if conflicts:
        print(f"AUDIO_DURATION_CONFLICT: {', '.join(conflicts)}", file=sys.stderr)
        return 2
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--skip-tts",
        action="store_true",
        help="Reconvert and validate existing MP3 sources without network access",
    )
    args = parser.parse_args()
    return asyncio.run(async_main(args.skip_tts))


if __name__ == "__main__":
    raise SystemExit(main())
