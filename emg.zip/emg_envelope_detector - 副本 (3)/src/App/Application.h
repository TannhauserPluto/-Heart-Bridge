#pragma once

#include "Core/Config.h"
#include "Core/Timing.h"
#include "Audio/AudioManager.h"
#include "Communication/NotificationService.h"
#include "Display/MainDisplay/MainDisplay.h"
#include "Display/PressSmallDisplay/PressSmallDisplay.h"
#include "Display/SmallDisplay/SmallDisplay.h"
#include "EMG/EmgEventAdapter.h"
#include "EMG/EMGDetector.h"
#include "Input/MicroMotionSensor.h"
#include "Interaction/InteractionStateMachine.h"

namespace App {

class Application {
 public:
  void begin();
  void update();

 private:
  enum class StartupState : uint8_t {
    UNINITIALIZED,
    HARDWARE_READY,
    DISPLAYS_READY,
    RUNNING,
  };

  EMG::EMGDetector detector_;
  EMG::EmgEventAdapter emgEventAdapter_{detector_};
  Audio::AudioManager audioManager_;
  Input::MicroMotionSensor microMotionSensor_;
  Display::MainDisplay mainDisplay_;
  Display::SmallDisplay smallDisplay_;
  Display::PressSmallDisplay pressSmallDisplay_;
  Interaction::InteractionStateMachine interaction_;
  Communication::LocalNotificationService notificationService_;
  Core::PeriodicTimer smallDisplayTimer_{Core::Config::kSmallDisplayRefreshMs};
  Core::PeriodicTimer pressDisplayTimer_{Core::Config::kPressDisplayRefreshMs};
  StartupState startupState_ = StartupState::UNINITIALIZED;
  uint32_t inputGuardUntilMs_ = 0;
  uint8_t calibrationMicroTriggerCount_ = 0;
  bool emgInputDisabledForSession_ = false;
  uint8_t microRestartTriggerCount_ = 0;
  uint32_t microRestartWindowStartedMs_ = 0;
  Audio::VoicePrompt pendingVoicePrompt_ = Audio::VoicePrompt::NONE;
  bool voicePromptPending_ = false;

  void renderInteractionState();
  bool microRestartRequested(uint32_t nowMs, bool microTriggerEvent);
  static bool inputGuardOpen(uint32_t nowMs, uint32_t guardUntilMs);
};

}  // namespace App
