#pragma once

#include <Arduino.h>
#include <cstring>

namespace Communication {

struct BlePeerIdentity {
  bool valid = false;
  uint8_t addressType = 0;
  uint8_t address[6]{};
};

inline bool samePeer(const BlePeerIdentity& left,
                     const BlePeerIdentity& right) {
  return left.valid && right.valid &&
         left.addressType == right.addressType &&
         memcmp(left.address, right.address, sizeof(left.address)) == 0;
}

}  // namespace Communication
