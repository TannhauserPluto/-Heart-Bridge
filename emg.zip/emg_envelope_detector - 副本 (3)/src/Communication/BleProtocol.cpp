#include "Communication/BleProtocol.h"

#include <ArduinoJson.h>

#include <cstring>

#include "Interaction/NeedCatalog.h"

namespace Communication::BleProtocol {
namespace {

constexpr uint32_t kFrameTimeoutMs = 5000;

bool validUtf8(const uint8_t* value, size_t length) {
  for (size_t index = 0; index < length;) {
    const uint8_t lead = value[index++];
    if (lead <= 0x7F) {
      continue;
    }
    uint8_t continuationCount = 0;
    uint32_t codePoint = 0;
    uint32_t minimum = 0;
    if ((lead & 0xE0U) == 0xC0U) {
      continuationCount = 1;
      codePoint = lead & 0x1FU;
      minimum = 0x80;
    } else if ((lead & 0xF0U) == 0xE0U) {
      continuationCount = 2;
      codePoint = lead & 0x0FU;
      minimum = 0x800;
    } else if ((lead & 0xF8U) == 0xF0U) {
      continuationCount = 3;
      codePoint = lead & 0x07U;
      minimum = 0x10000;
    } else {
      return false;
    }
    if (index + continuationCount > length) {
      return false;
    }
    for (uint8_t part = 0; part < continuationCount; ++part) {
      const uint8_t continuation = value[index++];
      if ((continuation & 0xC0U) != 0x80U) {
        return false;
      }
      codePoint = (codePoint << 6U) | (continuation & 0x3FU);
    }
    if (codePoint < minimum || codePoint > 0x10FFFFU ||
        (codePoint >= 0xD800U && codePoint <= 0xDFFFU)) {
      return false;
    }
  }
  return true;
}

bool copyText(const char* source, char* destination, size_t destinationSize) {
  if (source == nullptr) {
    return false;
  }
  const size_t length = strlen(source);
  if (length == 0 || length >= destinationSize) {
    return false;
  }
  memcpy(destination, source, length + 1U);
  return true;
}

bool validType(const JsonVariantConst& value, const char* expected) {
  return value.is<const char*>() &&
         strcmp(value.as<const char*>(), expected) == 0;
}

}  // namespace

bool validDeviceId(const char* value) {
  if (value == nullptr || strlen(value) != 15U || value[0] != 'H' ||
      value[1] != 'B' || value[2] != '-') {
    return false;
  }
  for (size_t index = 3; index < 15U; ++index) {
    const char character = value[index];
    if (!((character >= '0' && character <= '9') ||
          (character >= 'A' && character <= 'F'))) {
      return false;
    }
  }
  return true;
}

bool validNeedId(const char* value) {
  if (value == nullptr || strlen(value) == 0U ||
      strlen(value) >= kNeedIdCapacity) {
    return false;
  }
  for (uint8_t index = 0; index < Interaction::needCount(); ++index) {
    if (strcmp(value, Interaction::needAt(index).idName) == 0) {
      return true;
    }
  }
  return false;
}

bool validRequestId(uint32_t value) {
  return value != 0U && value != kRequestIdExhausted;
}

bool encodeNeedRequest(const NeedRequest& request, EncodedFrame& output) {
  if (!validDeviceId(request.deviceId) || !validNeedId(request.needId) ||
      !validRequestId(request.requestId)) {
    return false;
  }
  char json[kMaxJsonBytes + 1U]{};
  const int written = snprintf(
      json, sizeof(json),
      "{\"v\":1,\"type\":\"need_request\",\"device_id\":\"%s\",\"request_id\":%lu,\"need_id\":\"%s\",\"uptime_ms\":%lu}",
      request.deviceId, static_cast<unsigned long>(request.requestId),
      request.needId, static_cast<unsigned long>(request.uptimeMs));
  if (written <= 0 || written > static_cast<int>(kMaxJsonBytes)) {
    return false;
  }
  output.length = static_cast<uint16_t>(written + 2);
  output.bytes[0] = static_cast<uint8_t>(written >> 8U);
  output.bytes[1] = static_cast<uint8_t>(written & 0xFFU);
  memcpy(output.bytes + 2U, json, static_cast<size_t>(written));
  return true;
}

bool deviceInformationJson(const char* deviceId, char* output,
                           size_t outputSize) {
  if (!validDeviceId(deviceId) || output == nullptr || outputSize == 0U) {
    return false;
  }
  const int written = snprintf(
      output, outputSize,
      "{\"v\":1,\"protocol\":\"heartbridge-ble-v1\",\"device_id\":\"%s\"}",
      deviceId);
  return written > 0 && static_cast<size_t>(written) < outputSize &&
         written <= static_cast<int>(kMaxJsonBytes);
}

bool parseDeliveryAck(const uint8_t* json, size_t jsonLength,
                      DeliveryAck& output, ParseError& error) {
  error = ParseError::NONE;
  if (json == nullptr || jsonLength == 0U || jsonLength > kMaxJsonBytes) {
    error = ParseError::FRAME_LENGTH;
    return false;
  }
  if (!validUtf8(json, jsonLength)) {
    error = ParseError::UTF8;
    return false;
  }

  StaticJsonDocument<384> document;
  const DeserializationError deserializeError =
      deserializeJson(document, json, jsonLength,
                      DeserializationOption::NestingLimit(4));
  if (deserializeError || !document.is<JsonObject>()) {
    error = ParseError::JSON;
    return false;
  }
  const JsonObjectConst object = document.as<JsonObjectConst>();
  const JsonVariantConst version = object["v"];
  if (!version.is<uint8_t>() || version.as<uint8_t>() != kProtocolVersion) {
    error = ParseError::VERSION;
    return false;
  }
  if (!validType(object["type"], "delivery_ack")) {
    error = ParseError::TYPE;
    return false;
  }
  const JsonVariantConst deviceId = object["device_id"];
  const JsonVariantConst requestId = object["request_id"];
  if (!deviceId.is<const char*>() || !requestId.is<uint32_t>() ||
      !copyText(deviceId.as<const char*>(), output.deviceId,
                sizeof(output.deviceId)) ||
      !validDeviceId(output.deviceId) ||
      !validRequestId(requestId.as<uint32_t>())) {
    error = ParseError::FIELD;
    return false;
  }
  output.requestId = requestId.as<uint32_t>();
  return true;
}

const char* parseErrorName(ParseError error) {
  switch (error) {
    case ParseError::NONE:
      return "none";
    case ParseError::FRAME_LENGTH:
      return "frame_length";
    case ParseError::UTF8:
      return "utf8";
    case ParseError::JSON:
      return "json";
    case ParseError::VERSION:
      return "version";
    case ParseError::TYPE:
      return "type";
    case ParseError::FIELD:
      return "field";
  }
  return "unknown";
}

FrameResult FrameReassembler::push(const uint8_t* bytes, size_t length,
                                   uint32_t nowMs,
                                   const uint8_t*& completedJson,
                                   uint16_t& completedLength) {
  completedJson = nullptr;
  completedLength = 0;
  if (bytes == nullptr || length == 0U || length > kMaxFrameBytes) {
    reset();
    return FrameResult::INVALID;
  }
  if (!active_) {
    active_ = true;
    received_ = 0;
    expectedJsonLength_ = 0;
  }
  lastFragmentMs_ = nowMs;
  for (size_t index = 0; index < length; ++index) {
    if (received_ >= sizeof(frame_)) {
      reset();
      return FrameResult::INVALID;
    }
    frame_[received_++] = bytes[index];
    if (received_ == 2U) {
      expectedJsonLength_ =
          static_cast<uint16_t>((static_cast<uint16_t>(frame_[0]) << 8U) |
                                frame_[1]);
      if (expectedJsonLength_ == 0U || expectedJsonLength_ > kMaxJsonBytes) {
        reset();
        return FrameResult::INVALID;
      }
    }
    if (expectedJsonLength_ != 0U &&
        received_ == expectedJsonLength_ + 2U) {
      if (index + 1U != length) {
        reset();
        return FrameResult::INVALID;
      }
      completedJson = frame_ + 2U;
      completedLength = expectedJsonLength_;
      active_ = false;
      received_ = 0;
      expectedJsonLength_ = 0;
      return FrameResult::COMPLETE;
    }
  }
  return FrameResult::NONE;
}

bool FrameReassembler::expire(uint32_t nowMs) {
  if (!active_ || nowMs - lastFragmentMs_ < kFrameTimeoutMs) {
    return false;
  }
  reset();
  return true;
}

void FrameReassembler::reset() {
  active_ = false;
  received_ = 0;
  expectedJsonLength_ = 0;
  lastFragmentMs_ = 0;
}

}  // namespace Communication::BleProtocol
