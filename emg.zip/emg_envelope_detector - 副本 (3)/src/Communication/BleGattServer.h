#pragma once

#include <Arduino.h>

#include "BleProtocol.h"
#include "BleTypes.h"

class NimBLEAdvertising;
class NimBLECharacteristic;
class NimBLEServer;
class QueueDefinition;
typedef QueueDefinition* QueueHandle_t;

namespace Communication {

// Events are copied from NimBLE's callback task and consumed later from the
// application loop.  The fixed buffer deliberately bounds callback work.
struct GattEvent {
  enum class Type : uint8_t {
    CONNECTED,
    DISCONNECTED,
    SUBSCRIPTION,
    MTU_CHANGED,
    AUTH_COMPLETE,
    ACK_FRAGMENT,
  };

  Type type = Type::CONNECTED;
  uint16_t connectionHandle = 0;
  BlePeerIdentity peer{};
  bool encrypted = false;
  bool bonded = false;
  bool notifyEnabled = false;
  bool truncated = false;
  uint16_t mtu = 23;
  uint16_t dataLength = 0;
  uint8_t data[BleProtocol::kMaxFrameBytes]{};
};

class BleGattServer {
 public:
  static constexpr uint16_t kDefaultMtu = 23;

  BleGattServer() = default;
  bool begin(const char* deviceId);
  bool pollEvent(GattEvent& event);
  bool takeCallbackOverflow();

  // NimBLE-Arduino 1.4 exposes notify as void.  A true result only means the
  // characteristic accepted the fragment for the BLE stack; delivery is still
  // established exclusively by a matching ACK.
  bool notifyFragment(const uint8_t* bytes, uint16_t length);
  void startSecurity(uint16_t connectionHandle);
  void disconnect(uint16_t connectionHandle);
  void restartAdvertising();

 private:
  class ServerCallbacks;
  class AckCallbacks;

  bool enqueueEvent(const GattEvent& event);

  NimBLEServer* server_ = nullptr;
  NimBLEAdvertising* advertising_ = nullptr;
  NimBLECharacteristic* needCharacteristic_ = nullptr;
  QueueHandle_t eventQueue_ = nullptr;
  volatile bool callbackOverflow_ = false;
  bool started_ = false;
};

}  // namespace Communication
