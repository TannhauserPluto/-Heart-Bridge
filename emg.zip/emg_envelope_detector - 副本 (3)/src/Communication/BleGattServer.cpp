#include "BleGattServer.h"

#include <NimBLEDevice.h>

#include <cstring>

#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"

namespace Communication {

namespace {

BlePeerIdentity peerFromDescriptor(const ble_gap_conn_desc* descriptor) {
  BlePeerIdentity peer{};
  if (descriptor == nullptr) {
    return peer;
  }
  peer.valid = true;
  peer.addressType = descriptor->peer_id_addr.type;
  memcpy(peer.address, descriptor->peer_id_addr.val, sizeof(peer.address));
  return peer;
}

GattEvent baseEvent(GattEvent::Type type, const ble_gap_conn_desc* descriptor) {
  GattEvent event{};
  event.type = type;
  if (descriptor != nullptr) {
    event.connectionHandle = descriptor->conn_handle;
    event.peer = peerFromDescriptor(descriptor);
    event.encrypted = descriptor->sec_state.encrypted;
    event.bonded = descriptor->sec_state.bonded;
  }
  return event;
}

}  // namespace

class BleGattServer::ServerCallbacks : public NimBLEServerCallbacks {
 public:
  explicit ServerCallbacks(BleGattServer& owner) : owner_(owner) {}

  void onConnect(NimBLEServer*, ble_gap_conn_desc* descriptor) override {
    owner_.enqueueEvent(baseEvent(GattEvent::Type::CONNECTED, descriptor));
  }

  void onDisconnect(NimBLEServer*, ble_gap_conn_desc* descriptor) override {
    owner_.enqueueEvent(baseEvent(GattEvent::Type::DISCONNECTED, descriptor));
  }

  void onMTUChange(uint16_t mtu, ble_gap_conn_desc* descriptor) override {
    GattEvent event = baseEvent(GattEvent::Type::MTU_CHANGED, descriptor);
    event.mtu = mtu;
    owner_.enqueueEvent(event);
  }

  void onAuthenticationComplete(ble_gap_conn_desc* descriptor) override {
    owner_.enqueueEvent(baseEvent(GattEvent::Type::AUTH_COMPLETE, descriptor));
  }

 private:
  BleGattServer& owner_;
};

class BleGattServer::AckCallbacks : public NimBLECharacteristicCallbacks {
 public:
  explicit AckCallbacks(BleGattServer& owner) : owner_(owner) {}

  void onWrite(NimBLECharacteristic* characteristic,
               ble_gap_conn_desc* descriptor) override {
    GattEvent event = baseEvent(GattEvent::Type::ACK_FRAGMENT, descriptor);
    const NimBLEAttValue value = characteristic->getValue();
    event.truncated = value.length() > sizeof(event.data);
    event.dataLength = static_cast<uint16_t>(
        event.truncated ? sizeof(event.data) : value.length());
    if (event.dataLength > 0) {
      memcpy(event.data, value.data(), event.dataLength);
    }
    owner_.enqueueEvent(event);
  }

  void onSubscribe(NimBLECharacteristic*, ble_gap_conn_desc* descriptor,
                   uint16_t value) override {
    GattEvent event = baseEvent(GattEvent::Type::SUBSCRIPTION, descriptor);
    event.notifyEnabled = (value & 0x0001U) != 0;
    owner_.enqueueEvent(event);
  }

 private:
  BleGattServer& owner_;
};

bool BleGattServer::begin(const char* deviceId) {
  if (started_ || deviceId == nullptr) {
    return started_;
  }

  eventQueue_ = xQueueCreate(8, sizeof(GattEvent));
  if (eventQueue_ == nullptr) {
    return false;
  }

  NimBLEDevice::init("HeartBridge");
  NimBLEDevice::setSecurityAuth(true, false, true);
  NimBLEDevice::setSecurityIOCap(BLE_HS_IO_NO_INPUT_OUTPUT);
  NimBLEDevice::setMTU(247);

  server_ = NimBLEDevice::createServer();
  if (server_ == nullptr) {
    return false;
  }
  server_->setCallbacks(new ServerCallbacks(*this), true);

  NimBLEService* service = server_->createService(BleProtocol::kServiceUuid);
  if (service == nullptr) {
    return false;
  }
  needCharacteristic_ = service->createCharacteristic(
      BleProtocol::kNeedRequestUuid,
      NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::READ_ENC |
          NIMBLE_PROPERTY::NOTIFY,
      BleProtocol::kMaxFrameBytes);
  NimBLECharacteristic* ackCharacteristic = service->createCharacteristic(
      BleProtocol::kDeliveryAckUuid,
      NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_ENC,
      BleProtocol::kMaxFrameBytes);
  NimBLECharacteristic* deviceInformationCharacteristic =
      service->createCharacteristic(BleProtocol::kDeviceInformationUuid,
                                    NIMBLE_PROPERTY::READ,
                                    BleProtocol::kMaxJsonBytes);
  if (needCharacteristic_ == nullptr || ackCharacteristic == nullptr ||
      deviceInformationCharacteristic == nullptr) {
    return false;
  }

  char deviceInformation[BleProtocol::kMaxJsonBytes + 1]{};
  if (!BleProtocol::deviceInformationJson(deviceId, deviceInformation,
                                           sizeof(deviceInformation))) {
    return false;
  }
  deviceInformationCharacteristic->setValue(
      reinterpret_cast<const uint8_t*>(deviceInformation),
      strlen(deviceInformation));
  needCharacteristic_->setCallbacks(new AckCallbacks(*this));
  ackCharacteristic->setCallbacks(new AckCallbacks(*this));
  if (!service->start()) {
    return false;
  }

  advertising_ = NimBLEDevice::getAdvertising();
  if (advertising_ == nullptr) {
    return false;
  }
  advertising_->addServiceUUID(BleProtocol::kServiceUuid);
  advertising_->setScanResponse(true);
  if (!advertising_->start()) {
    return false;
  }
  started_ = true;
  return true;
}

bool BleGattServer::enqueueEvent(const GattEvent& event) {
  if (eventQueue_ != nullptr && xQueueSend(eventQueue_, &event, 0) == pdTRUE) {
    return true;
  }
  callbackOverflow_ = true;
  return false;
}

bool BleGattServer::pollEvent(GattEvent& event) {
  return eventQueue_ != nullptr && xQueueReceive(eventQueue_, &event, 0) == pdTRUE;
}

bool BleGattServer::takeCallbackOverflow() {
  const bool overflowed = callbackOverflow_;
  callbackOverflow_ = false;
  return overflowed;
}

bool BleGattServer::notifyFragment(const uint8_t* bytes, uint16_t length) {
  if (!started_ || needCharacteristic_ == nullptr || bytes == nullptr ||
      length == 0 || length > BleProtocol::kMaxFrameBytes) {
    return false;
  }
  needCharacteristic_->notify(bytes, length);
  return true;
}

void BleGattServer::startSecurity(uint16_t connectionHandle) {
  // This only initiates the GAP procedure; it does not wait for pairing and is
  // intentionally called from the application loop, never from a callback.
  NimBLEDevice::startSecurity(connectionHandle);
}

void BleGattServer::disconnect(uint16_t connectionHandle) {
  if (server_ != nullptr) {
    server_->disconnect(connectionHandle);
  }
}

void BleGattServer::restartAdvertising() {
  if (advertising_ != nullptr) {
    advertising_->start();
  }
}

}  // namespace Communication
