#pragma once

#include <Arduino.h>
#include <Preferences.h>

#include "BleProtocol.h"
#include "BleTypes.h"

namespace Communication {

// A compact, double-buffered NVS snapshot.  A request is never offered to the
// transport until the snapshot containing it has been committed successfully.
class PendingRequestStore {
 public:
  static constexpr uint8_t kCapacity = 16;

  enum class EnqueueResult : uint8_t {
    OK,
    STORAGE_UNAVAILABLE,
    REQUEST_ID_EXHAUSTED,
  };

  bool begin();
  bool recoveredCorruption() const { return recoveredCorruption_; }

  EnqueueResult enqueue(const char* deviceId, const char* needId,
                        uint32_t uptimeMs,
                        BleProtocol::NeedRequest& created,
                        bool& overflowed, uint32_t& removedRequestId,
                        uint32_t& overflowCount);

  uint8_t count() const { return state_.count; }
  const BleProtocol::NeedRequest* requestAt(uint8_t index) const;
  bool contains(uint32_t requestId) const;
  bool removeRequest(uint32_t requestId);

  bool hasBoundPeer() const { return state_.boundPeer.valid; }
  bool isBoundPeer(const BlePeerIdentity& peer) const;
  bool bindFirstPeer(const BlePeerIdentity& peer);
  const BlePeerIdentity& boundPeer() const { return state_.boundPeer; }

 private:
  static constexpr uint32_t kMagic = 0x48424331UL;  // "HBC1"
  static constexpr uint16_t kVersion = 1;
  static const char kNamespace[];
  static const char kSlotKeys[2][7];

  struct PersistedState {
    uint32_t magic = kMagic;
    uint16_t version = kVersion;
    uint16_t count = 0;
    uint32_t generation = 0;
    uint32_t nextRequestId = 1;
    uint32_t overflowCount = 0;
    BlePeerIdentity boundPeer{};
    BleProtocol::NeedRequest requests[kCapacity]{};
    uint32_t checksum = 0;
  };

  static uint32_t checksum(const PersistedState& state);
  static bool stateValid(const PersistedState& state);
  bool loadSlot(uint8_t slot, PersistedState& output, bool& keyPresent);
  bool commit(PersistedState candidate);

  Preferences preferences_;
  PersistedState state_{};
  int8_t activeSlot_ = -1;
  bool ready_ = false;
  bool recoveredCorruption_ = false;
};

}  // namespace Communication
