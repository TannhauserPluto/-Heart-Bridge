#pragma once

#include <Arduino.h>

#include "BleGattServer.h"
#include "BleProtocol.h"
#include "PendingRequestStore.h"

namespace Interaction {
struct NeedItem;
}

namespace Communication {

class BleDeliveryService {
 public:
  void begin();
  void update(uint32_t nowMs);

  // This is deliberately the sole application-facing request entrypoint.  It
  // persists before the request can reach the GATT transport.
  void createConfirmedRequest(const Interaction::NeedItem& need,
                              uint32_t uptimeMs);

 private:
  enum class SendState : uint8_t {
    PENDING,
    SENDING,
    WAITING_ACK,
    RETRY_WAIT,
  };

  struct ActiveRequest {
    uint32_t requestId = 0;
    SendState state = SendState::PENDING;
    BleProtocol::EncodedFrame frame{};
    uint16_t offset = 0;
    uint8_t retryCount = 0;
    uint32_t dueMs = 0;
    uint32_t retryDelayMs = 0;
    bool forceImmediate = false;
  };

  static bool due(uint32_t nowMs, uint32_t deadlineMs);
  static uint32_t retryDelayMs(uint8_t retryCount);
  static void makeDeviceId(char* output, size_t outputSize);

  void handleEvent(const GattEvent& event, uint32_t nowMs);
  void handleAckFragment(const GattEvent& event, uint32_t nowMs);
  void resetActiveForHead();
  bool connectedAndAuthorized() const;
  uint16_t notificationPayloadLimit() const;
  void serviceHead(uint32_t nowMs);
  void startSend(const BleProtocol::NeedRequest& request, uint32_t nowMs,
                 bool retry);
  void scheduleRetry(uint32_t nowMs);
  void acknowledge(const BleProtocol::DeliveryAck& ack);

  PendingRequestStore store_;
  BleGattServer gatt_;
  BleProtocol::FrameReassembler ackReassembler_;
  char deviceId_[BleProtocol::kDeviceIdCapacity]{};

  bool started_ = false;
  bool connected_ = false;
  bool authorized_ = false;
  bool notifyEnabled_ = false;
  uint16_t connectionHandle_ = 0;
  uint16_t peerMtu_ = BleGattServer::kDefaultMtu;
  BlePeerIdentity peer_{};
  uint32_t lastDeliveredRequestId_ = 0;
  ActiveRequest active_{};
};

}  // namespace Communication
