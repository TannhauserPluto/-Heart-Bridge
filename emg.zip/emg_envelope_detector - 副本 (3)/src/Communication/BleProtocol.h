#pragma once

#include <Arduino.h>

namespace Communication::BleProtocol {

constexpr uint8_t kProtocolVersion = 1;
constexpr size_t kMaxJsonBytes = 192;
constexpr size_t kMaxFrameBytes = kMaxJsonBytes + 2;
constexpr size_t kDeviceIdCapacity = 16;
constexpr size_t kNeedIdCapacity = 16;
constexpr uint32_t kRequestIdExhausted = UINT32_MAX;

constexpr const char* kServiceUuid = "9D5A0001-4F38-4E2C-8A71-2FB40A08B021";
constexpr const char* kNeedRequestUuid =
    "9D5A0002-4F38-4E2C-8A71-2FB40A08B021";
constexpr const char* kDeliveryAckUuid =
    "9D5A0003-4F38-4E2C-8A71-2FB40A08B021";
constexpr const char* kDeviceInformationUuid =
    "9D5A0004-4F38-4E2C-8A71-2FB40A08B021";

struct NeedRequest {
  char deviceId[kDeviceIdCapacity]{};
  uint32_t requestId = 0;
  char needId[kNeedIdCapacity]{};
  uint32_t uptimeMs = 0;
};

struct DeliveryAck {
  char deviceId[kDeviceIdCapacity]{};
  uint32_t requestId = 0;
};

struct EncodedFrame {
  uint8_t bytes[kMaxFrameBytes]{};
  uint16_t length = 0;
};

enum class ParseError : uint8_t {
  NONE,
  FRAME_LENGTH,
  UTF8,
  JSON,
  VERSION,
  TYPE,
  FIELD,
};

enum class FrameResult : uint8_t {
  NONE,
  COMPLETE,
  INVALID,
};

bool validDeviceId(const char* value);
bool validNeedId(const char* value);
bool validRequestId(uint32_t value);
bool encodeNeedRequest(const NeedRequest& request, EncodedFrame& output);
bool deviceInformationJson(const char* deviceId, char* output,
                           size_t outputSize);
bool parseDeliveryAck(const uint8_t* json, size_t jsonLength,
                      DeliveryAck& output, ParseError& error);
const char* parseErrorName(ParseError error);

class FrameReassembler {
 public:
  FrameResult push(const uint8_t* bytes, size_t length, uint32_t nowMs,
                   const uint8_t*& completedJson, uint16_t& completedLength);
  bool expire(uint32_t nowMs);
  void reset();

 private:
  uint8_t frame_[kMaxFrameBytes]{};
  uint16_t received_ = 0;
  uint16_t expectedJsonLength_ = 0;
  uint32_t lastFragmentMs_ = 0;
  bool active_ = false;
};

}  // namespace Communication::BleProtocol
