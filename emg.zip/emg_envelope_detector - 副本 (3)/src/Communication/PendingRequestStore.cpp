#include "PendingRequestStore.h"

#include <cstring>

namespace Communication {

const char PendingRequestStore::kNamespace[] = "hb_comm_v1";
const char PendingRequestStore::kSlotKeys[2][7] = {"state0", "state1"};

namespace {

uint32_t fnv1a(const uint8_t* bytes, size_t length) {
  uint32_t hash = 2166136261UL;
  for (size_t index = 0; index < length; ++index) {
    hash ^= bytes[index];
    hash *= 16777619UL;
  }
  return hash;
}

bool generationNewer(uint32_t left, uint32_t right) {
  return static_cast<int32_t>(left - right) > 0;
}

}  // namespace

uint32_t PendingRequestStore::checksum(const PersistedState& state) {
  return fnv1a(reinterpret_cast<const uint8_t*>(&state),
               offsetof(PersistedState, checksum));
}

bool PendingRequestStore::stateValid(const PersistedState& state) {
  if (state.magic != kMagic || state.version != kVersion ||
      state.count > kCapacity || state.nextRequestId == 0 ||
      state.checksum != checksum(state)) {
    return false;
  }

  if (state.boundPeer.valid && state.boundPeer.addressType > 1) {
    return false;
  }

  uint32_t previousRequestId = 0;
  for (uint8_t index = 0; index < state.count; ++index) {
    const BleProtocol::NeedRequest& request = state.requests[index];
    if (!BleProtocol::validDeviceId(request.deviceId) ||
        !BleProtocol::validNeedId(request.needId) ||
        !BleProtocol::validRequestId(request.requestId) ||
        (index > 0 && request.requestId <= previousRequestId)) {
      return false;
    }
    previousRequestId = request.requestId;
  }
  return true;
}

bool PendingRequestStore::loadSlot(uint8_t slot, PersistedState& output,
                                   bool& keyPresent) {
  keyPresent = preferences_.isKey(kSlotKeys[slot]);
  if (!keyPresent ||
      preferences_.getBytesLength(kSlotKeys[slot]) != sizeof(output)) {
    return false;
  }
  if (preferences_.getBytes(kSlotKeys[slot], &output, sizeof(output)) !=
      sizeof(output)) {
    return false;
  }
  return stateValid(output);
}

bool PendingRequestStore::commit(PersistedState candidate) {
  if (!ready_) {
    return false;
  }

  const uint8_t targetSlot = activeSlot_ == 0 ? 1 : 0;
  candidate.magic = kMagic;
  candidate.version = kVersion;
  candidate.generation = activeSlot_ < 0 ? 1 : state_.generation + 1;
  candidate.checksum = checksum(candidate);

  if (preferences_.putBytes(kSlotKeys[targetSlot], &candidate,
                            sizeof(candidate)) != sizeof(candidate)) {
    return false;
  }

  state_ = candidate;
  activeSlot_ = static_cast<int8_t>(targetSlot);
  return true;
}

bool PendingRequestStore::begin() {
  if (!preferences_.begin(kNamespace, false)) {
    return false;
  }
  ready_ = true;

  PersistedState slotStates[2]{};
  bool present[2] = {false, false};
  const bool valid0 = loadSlot(0, slotStates[0], present[0]);
  const bool valid1 = loadSlot(1, slotStates[1], present[1]);

  if (valid0 || valid1) {
    const uint8_t selected =
        valid0 && (!valid1 || generationNewer(slotStates[0].generation,
                                               slotStates[1].generation))
            ? 0
            : 1;
    state_ = slotStates[selected];
    activeSlot_ = static_cast<int8_t>(selected);
    return true;
  }

  state_ = PersistedState{};
  activeSlot_ = -1;
  // If a snapshot existed but neither copy was valid, do not risk reusing an
  // ID after an ambiguous power loss or corrupted NVS record.
  if (present[0] || present[1]) {
    state_.nextRequestId = BleProtocol::kRequestIdExhausted;
    recoveredCorruption_ = true;
  }
  return commit(state_);
}

PendingRequestStore::EnqueueResult PendingRequestStore::enqueue(
    const char* deviceId, const char* needId, uint32_t uptimeMs,
    BleProtocol::NeedRequest& created, bool& overflowed,
    uint32_t& removedRequestId, uint32_t& overflowCount) {
  overflowed = false;
  removedRequestId = 0;
  overflowCount = state_.overflowCount;
  if (!ready_) {
    return EnqueueResult::STORAGE_UNAVAILABLE;
  }
  if (state_.nextRequestId == BleProtocol::kRequestIdExhausted) {
    return EnqueueResult::REQUEST_ID_EXHAUSTED;
  }

  PersistedState candidate = state_;
  BleProtocol::NeedRequest request{};
  strncpy(request.deviceId, deviceId, sizeof(request.deviceId) - 1);
  strncpy(request.needId, needId, sizeof(request.needId) - 1);
  request.requestId = candidate.nextRequestId;
  request.uptimeMs = uptimeMs;
  if (!BleProtocol::validDeviceId(request.deviceId) ||
      !BleProtocol::validNeedId(request.needId)) {
    return EnqueueResult::STORAGE_UNAVAILABLE;
  }

  ++candidate.nextRequestId;
  if (candidate.count == kCapacity) {
    overflowed = true;
    removedRequestId = candidate.requests[0].requestId;
    for (uint8_t index = 1; index < kCapacity; ++index) {
      candidate.requests[index - 1] = candidate.requests[index];
    }
    --candidate.count;
    ++candidate.overflowCount;
  }
  candidate.requests[candidate.count++] = request;

  if (!commit(candidate)) {
    return EnqueueResult::STORAGE_UNAVAILABLE;
  }

  created = request;
  overflowCount = state_.overflowCount;
  return EnqueueResult::OK;
}

const BleProtocol::NeedRequest* PendingRequestStore::requestAt(
    uint8_t index) const {
  return index < state_.count ? &state_.requests[index] : nullptr;
}

bool PendingRequestStore::contains(uint32_t requestId) const {
  for (uint8_t index = 0; index < state_.count; ++index) {
    if (state_.requests[index].requestId == requestId) {
      return true;
    }
  }
  return false;
}

bool PendingRequestStore::removeRequest(uint32_t requestId) {
  if (!ready_) {
    return false;
  }
  PersistedState candidate = state_;
  uint8_t found = kCapacity;
  for (uint8_t index = 0; index < candidate.count; ++index) {
    if (candidate.requests[index].requestId == requestId) {
      found = index;
      break;
    }
  }
  if (found == kCapacity) {
    return true;
  }
  for (uint8_t index = found + 1; index < candidate.count; ++index) {
    candidate.requests[index - 1] = candidate.requests[index];
  }
  --candidate.count;
  memset(&candidate.requests[candidate.count], 0,
         sizeof(candidate.requests[candidate.count]));
  return commit(candidate);
}

bool PendingRequestStore::isBoundPeer(const BlePeerIdentity& peer) const {
  return samePeer(state_.boundPeer, peer);
}

bool PendingRequestStore::bindFirstPeer(const BlePeerIdentity& peer) {
  if (!peer.valid) {
    return false;
  }
  if (state_.boundPeer.valid) {
    return isBoundPeer(peer);
  }
  PersistedState candidate = state_;
  candidate.boundPeer = peer;
  return commit(candidate);
}

}  // namespace Communication
