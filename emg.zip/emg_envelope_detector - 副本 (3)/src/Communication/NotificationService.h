#pragma once

#include <Arduino.h>

#include "Communication/BleDeliveryService.h"
#include "Interaction/NeedCatalog.h"

namespace Communication {

// Local-only notification boundary.  It deliberately makes no claim that a
// network message or phone call was sent; that can be added behind this API.
class LocalNotificationService {
 public:
  void begin();
  void update(uint32_t nowMs);
  void createConfirmedRequest(const Interaction::NeedItem& need,
                              uint32_t timestampMs);

 private:
  BleDeliveryService bleDeliveryService_;
};

}  // namespace Communication
