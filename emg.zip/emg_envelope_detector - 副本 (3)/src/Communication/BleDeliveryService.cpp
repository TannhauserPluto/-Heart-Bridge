#include "BleDeliveryService.h"

#include <cstring>

#include "Interaction/NeedCatalog.h"

namespace Communication {

namespace {

const char* needIdFor(const BleProtocol::NeedRequest& request) {
  return request.needId[0] == '\0' ? "unknown" : request.needId;
}

void logRequest(const char* event, const BleProtocol::NeedRequest& request) {
  Serial.printf("[COMM] %s request_id=%lu need_id=%s\n", event,
                static_cast<unsigned long>(request.requestId),
                needIdFor(request));
}

}  // namespace

bool BleDeliveryService::due(uint32_t nowMs, uint32_t deadlineMs) {
  return static_cast<int32_t>(nowMs - deadlineMs) >= 0;
}

uint32_t BleDeliveryService::retryDelayMs(uint8_t retryCount) {
  switch (retryCount) {
    case 0:
      return 2000;
    case 1:
      return 4000;
    case 2:
      return 8000;
    case 3:
      return 15000;
    default:
      return 30000;
  }
}

void BleDeliveryService::makeDeviceId(char* output, size_t outputSize) {
  const uint64_t mac = ESP.getEfuseMac() & 0x0000FFFFFFFFFFFFULL;
  snprintf(output, outputSize, "HB-%012llX",
           static_cast<unsigned long long>(mac));
}

void BleDeliveryService::begin() {
  if (started_) {
    return;
  }
  makeDeviceId(deviceId_, sizeof(deviceId_));

  const bool storeReady = store_.begin();
  if (!storeReady) {
    Serial.println("[COMM] persist_failed reason=nvs_open");
  } else if (store_.recoveredCorruption()) {
    Serial.println(
        "[COMM] persist_failed reason=nvs_corrupt_recovered_fail_closed");
  }

  if (!gatt_.begin(deviceId_)) {
    Serial.println("[COMM] ble_start_failed");
    return;
  }
  started_ = true;
  Serial.printf("[COMM] ble_started device_id=%s pending=%u\n", deviceId_,
                store_.count());
}

void BleDeliveryService::createConfirmedRequest(
    const Interaction::NeedItem& need, uint32_t uptimeMs) {
  BleProtocol::NeedRequest created{};
  bool overflowed = false;
  uint32_t removedRequestId = 0;
  uint32_t overflowCount = 0;
  const PendingRequestStore::EnqueueResult result =
      store_.enqueue(deviceId_, need.idName, uptimeMs, created, overflowed,
                     removedRequestId, overflowCount);
  if (result == PendingRequestStore::EnqueueResult::REQUEST_ID_EXHAUSTED) {
    Serial.printf("[COMM] persist_failed reason=request_id_exhausted need_id=%s\n",
                  need.idName);
    return;
  }
  if (result != PendingRequestStore::EnqueueResult::OK) {
    Serial.printf("[COMM] persist_failed reason=enqueue need_id=%s\n",
                  need.idName);
    return;
  }

  logRequest("queued", created);
  logRequest("persisted", created);
  if (overflowed) {
    Serial.printf(
        "[COMM] queue_overflow removed_request_id=%lu overflow_count=%lu "
        "kept_request_id=%lu need_id=%s\n",
        static_cast<unsigned long>(removedRequestId),
        static_cast<unsigned long>(overflowCount),
        static_cast<unsigned long>(created.requestId), created.needId);
  }
  active_.forceImmediate = true;
}

void BleDeliveryService::update(uint32_t nowMs) {
  if (!started_) {
    return;
  }

  // Bound one event per application update: GATT callbacks only enqueue data,
  // and neither a burst of writes nor JSON parsing can monopolize this loop.
  GattEvent event{};
  if (gatt_.pollEvent(event)) {
    handleEvent(event, nowMs);
  }
  if (gatt_.takeCallbackOverflow()) {
    Serial.println("[COMM] invalid_ack reason=callback_queue_overflow");
    ackReassembler_.reset();
  }
  if (ackReassembler_.expire(nowMs)) {
    Serial.println("[COMM] invalid_ack reason=frame_timeout");
  }

  serviceHead(nowMs);
}

void BleDeliveryService::handleEvent(const GattEvent& event, uint32_t nowMs) {
  switch (event.type) {
    case GattEvent::Type::CONNECTED:
      connected_ = true;
      authorized_ = false;
      notifyEnabled_ = false;
      connectionHandle_ = event.connectionHandle;
      peerMtu_ = BleGattServer::kDefaultMtu;
      peer_ = event.peer;
      ackReassembler_.reset();
      Serial.printf("[COMM] connected conn_handle=%u\n", connectionHandle_);
      if (store_.hasBoundPeer() && !store_.isBoundPeer(peer_)) {
        Serial.println("[COMM] disconnected reason=unbound_peer_rejected");
        gatt_.disconnect(connectionHandle_);
      } else {
        // Pairing is explicitly initiated here so a newly provisioned phone
        // cannot be stuck waiting for an encrypted notification before it has
        // a chance to perform its first encrypted ACK write.
        gatt_.startSecurity(connectionHandle_);
      }
      break;

    case GattEvent::Type::DISCONNECTED:
      if (event.connectionHandle != connectionHandle_) {
        break;
      }
      Serial.printf("[COMM] disconnected conn_handle=%u\n",
                    connectionHandle_);
      connected_ = false;
      authorized_ = false;
      notifyEnabled_ = false;
      peerMtu_ = BleGattServer::kDefaultMtu;
      peer_ = BlePeerIdentity{};
      ackReassembler_.reset();
      if (active_.requestId != 0) {
        active_.state = SendState::PENDING;
        active_.offset = 0;
        active_.forceImmediate = true;
      }
      gatt_.restartAdvertising();
      break;

    case GattEvent::Type::MTU_CHANGED:
      if (event.connectionHandle == connectionHandle_) {
        peerMtu_ = event.mtu >= BleGattServer::kDefaultMtu
                       ? event.mtu
                       : BleGattServer::kDefaultMtu;
      }
      break;

    case GattEvent::Type::AUTH_COMPLETE:
      if (event.connectionHandle != connectionHandle_) {
        break;
      }
      if (!event.encrypted || !event.bonded || !event.peer.valid) {
        Serial.println("[COMM] disconnected reason=bonding_failed");
        gatt_.disconnect(connectionHandle_);
        break;
      }
      if (store_.hasBoundPeer()) {
        if (!store_.isBoundPeer(event.peer)) {
          Serial.println("[COMM] disconnected reason=unbound_peer_rejected");
          gatt_.disconnect(connectionHandle_);
          break;
        }
      } else if (!store_.bindFirstPeer(event.peer)) {
        Serial.println("[COMM] persist_failed reason=bind_first_peer");
        gatt_.disconnect(connectionHandle_);
        break;
      }
      peer_ = event.peer;
      authorized_ = true;
      Serial.printf("[COMM] bonded conn_handle=%u\n", connectionHandle_);
      active_.forceImmediate = true;
      break;

    case GattEvent::Type::SUBSCRIPTION:
      if (event.connectionHandle == connectionHandle_ &&
          samePeer(event.peer, peer_)) {
        notifyEnabled_ = event.notifyEnabled;
        if (notifyEnabled_ && authorized_) {
          active_.forceImmediate = true;
        }
      }
      break;

    case GattEvent::Type::ACK_FRAGMENT:
      handleAckFragment(event, nowMs);
      break;
  }
}

void BleDeliveryService::handleAckFragment(const GattEvent& event,
                                           uint32_t nowMs) {
  if (!connectedAndAuthorized() || event.connectionHandle != connectionHandle_ ||
      !samePeer(event.peer, peer_)) {
    Serial.println("[COMM] invalid_ack reason=unauthorized_peer");
    return;
  }
  if (event.truncated) {
    ackReassembler_.reset();
    Serial.println("[COMM] invalid_ack reason=fragment_too_large");
    return;
  }

  const uint8_t* completed = nullptr;
  uint16_t completedLength = 0;
  const BleProtocol::FrameResult frameResult = ackReassembler_.push(
      event.data, event.dataLength, nowMs, completed, completedLength);
  if (frameResult == BleProtocol::FrameResult::INVALID) {
    Serial.println("[COMM] invalid_ack reason=frame");
    return;
  }
  if (frameResult != BleProtocol::FrameResult::COMPLETE) {
    return;
  }

  BleProtocol::DeliveryAck ack{};
  BleProtocol::ParseError error = BleProtocol::ParseError::NONE;
  if (!BleProtocol::parseDeliveryAck(completed, completedLength, ack, error)) {
    Serial.printf("[COMM] invalid_ack reason=%s\n",
                  BleProtocol::parseErrorName(error));
    return;
  }
  if (strcmp(ack.deviceId, deviceId_) != 0) {
    Serial.printf("[COMM] ack_mismatch reason=device_id request_id=%lu\n",
                  static_cast<unsigned long>(ack.requestId));
    return;
  }
  acknowledge(ack);
}

void BleDeliveryService::acknowledge(const BleProtocol::DeliveryAck& ack) {
  if (!store_.contains(ack.requestId)) {
    const char* event = ack.requestId == lastDeliveredRequestId_
                            ? "ack_duplicate"
                            : "ack_stale";
    Serial.printf("[COMM] %s request_id=%lu\n", event,
                  static_cast<unsigned long>(ack.requestId));
    return;
  }
  const BleProtocol::NeedRequest* request = store_.requestAt(0);
  char needId[BleProtocol::kNeedIdCapacity]{};
  if (request != nullptr && request->requestId == ack.requestId) {
    strncpy(needId, request->needId, sizeof(needId) - 1);
  }
  if (!store_.removeRequest(ack.requestId)) {
    Serial.printf("[COMM] persist_failed reason=remove_ack request_id=%lu\n",
                  static_cast<unsigned long>(ack.requestId));
    return;
  }
  lastDeliveredRequestId_ = ack.requestId;
  Serial.printf("[COMM] delivered request_id=%lu need_id=%s\n",
                static_cast<unsigned long>(ack.requestId), needId);
  resetActiveForHead();
  active_.forceImmediate = true;
}

void BleDeliveryService::resetActiveForHead() {
  const BleProtocol::NeedRequest* head = store_.requestAt(0);
  if (head == nullptr) {
    active_ = ActiveRequest{};
    return;
  }
  if (active_.requestId != head->requestId) {
    active_ = ActiveRequest{};
    active_.requestId = head->requestId;
  }
}

bool BleDeliveryService::connectedAndAuthorized() const {
  return connected_ && authorized_ && notifyEnabled_;
}

uint16_t BleDeliveryService::notificationPayloadLimit() const {
  if (peerMtu_ <= 3) {
    return 20;
  }
  return peerMtu_ - 3;
}

void BleDeliveryService::serviceHead(uint32_t nowMs) {
  resetActiveForHead();
  const BleProtocol::NeedRequest* request = store_.requestAt(0);
  if (request == nullptr || !connectedAndAuthorized()) {
    return;
  }

  if (active_.state == SendState::WAITING_ACK &&
      due(nowMs, active_.dueMs)) {
    logRequest("ack_timeout", *request);
    scheduleRetry(nowMs);
  }
  if (active_.state == SendState::RETRY_WAIT &&
      (active_.forceImmediate || due(nowMs, active_.dueMs))) {
    startSend(*request, nowMs, true);
  }
  if (active_.state == SendState::PENDING) {
    startSend(*request, nowMs, false);
  }
  if (active_.state != SendState::SENDING) {
    return;
  }

  const uint16_t payloadLimit = notificationPayloadLimit();
  const uint16_t remaining = active_.frame.length - active_.offset;
  const uint16_t fragmentLength =
      remaining < payloadLimit ? remaining : payloadLimit;
  if (fragmentLength == 0 ||
      !gatt_.notifyFragment(active_.frame.bytes + active_.offset,
                            fragmentLength)) {
    Serial.printf("[COMM] ack_timeout request_id=%lu need_id=%s reason=notify\n",
                  static_cast<unsigned long>(request->requestId),
                  needIdFor(*request));
    scheduleRetry(nowMs);
    return;
  }

  active_.offset += fragmentLength;
  if (active_.offset < active_.frame.length) {
    return;
  }
  active_.state = SendState::WAITING_ACK;
  active_.dueMs = nowMs + 2000;
  Serial.printf("[COMM] sent request_id=%lu need_id=%s attempt=%u\n",
                static_cast<unsigned long>(request->requestId),
                needIdFor(*request), active_.retryCount);
  active_.forceImmediate = false;
}

void BleDeliveryService::startSend(const BleProtocol::NeedRequest& request,
                                   uint32_t nowMs, bool retry) {
  if (!BleProtocol::encodeNeedRequest(request, active_.frame)) {
    Serial.printf("[COMM] persist_failed reason=encode request_id=%lu\n",
                  static_cast<unsigned long>(request.requestId));
    active_.state = SendState::RETRY_WAIT;
    active_.dueMs = nowMs + 30000;
    active_.forceImmediate = false;
    return;
  }
  active_.offset = 0;
  active_.state = SendState::SENDING;
  if (retry) {
    Serial.printf(
        "[COMM] retry request_id=%lu need_id=%s attempt=%u delay_ms=%lu\n",
        static_cast<unsigned long>(request.requestId), needIdFor(request),
        active_.retryCount, static_cast<unsigned long>(active_.retryDelayMs));
  }
}

void BleDeliveryService::scheduleRetry(uint32_t nowMs) {
  active_.retryDelayMs = retryDelayMs(active_.retryCount);
  if (active_.retryCount != UINT8_MAX) {
    ++active_.retryCount;
  }
  active_.state = SendState::RETRY_WAIT;
  active_.offset = 0;
  active_.dueMs = nowMs + active_.retryDelayMs;
  active_.forceImmediate = false;
}

}  // namespace Communication
