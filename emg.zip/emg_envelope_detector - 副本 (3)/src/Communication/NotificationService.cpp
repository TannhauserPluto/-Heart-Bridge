#include "NotificationService.h"

namespace Communication {

void LocalNotificationService::begin() {
  bleDeliveryService_.begin();
}

void LocalNotificationService::update(uint32_t nowMs) {
  bleDeliveryService_.update(nowMs);
}

void LocalNotificationService::createConfirmedRequest(
    const Interaction::NeedItem& need, uint32_t timestampMs) {
  Serial.printf(
      "[REQUEST] REQUEST_CREATED need_id=%s need_text=%s timestamp_ms=%lu "
      "confirmed=true\n",
      need.idName, need.displayText, static_cast<unsigned long>(timestampMs));
  bleDeliveryService_.createConfirmedRequest(need, timestampMs);
}

}  // namespace Communication
