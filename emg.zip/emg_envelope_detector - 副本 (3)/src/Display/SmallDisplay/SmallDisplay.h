#pragma once

#include <Arduino.h>

namespace Display {

// GC9D01 secondary display.  Its only presentation responsibility is a
// display-only visualization of the existing EMG strength result.
class SmallDisplay {
 public:
  void begin();
  void updateEmgStrength(bool detectorReady, float normalizedEnvelope);

 private:
  void initializeGc9d01();
  void setAddress(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);
  void fillRectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height,
                     uint16_t color);
  void drawMeterBackground();
  void drawScaleElements(uint16_t yStart, uint16_t yEnd);
  void restorePointerBackground(uint16_t pointerY);
  void drawPointer(uint16_t pointerY);
  float mapNormalizedToDisplayStrength(bool detectorReady,
                                       float normalizedEnvelope) const;
  uint16_t strengthToPointerY(float displayStrength) const;

  bool initialized_ = false;
  bool pointerDrawn_ = false;
  float smoothedStrength_ = 0.0f;
  uint16_t pointerY_ = 0;
};

}  // namespace Display
