#include "PressSmallDisplay.h"

#include <cmath>

#include "Core/DisplayBus.h"
#include "Core/Hardware.h"

namespace Display {
namespace {

constexpr uint16_t kWidth = 40;
constexpr uint16_t kHeight = 160;
constexpr uint16_t kWhite = 0xFFFF;
constexpr uint16_t kGrey = 0x8410;
constexpr uint16_t kRed = 0xF800;

constexpr uint16_t kScaleTopY = 14;
constexpr uint16_t kScaleBottomY = 146;
constexpr uint16_t kAxisX = 16;
constexpr uint16_t kMajorTickLength = 12;
constexpr uint16_t kMinorTickLength = 6;
constexpr uint8_t kTickIntervals = 12;
constexpr uint16_t kPointerX = 3;
constexpr uint16_t kPointerWidth = 34;
constexpr uint16_t kPointerHeight = 2;
// GC9D01 DCS brightness: 00 is lowest and FF is highest.  This is applied
// once after the verified initialization sequence, without changing it.
constexpr uint8_t kDisplayBrightness = 0x80;
constexpr uint8_t kBrightnessControlEnabled = 0x24;  // BCTRL | BL
constexpr uint16_t kIdleAdc = 4095;
constexpr uint16_t kFullPressAdc = 0;
constexpr float kAttackAlpha = 0.45f;
constexpr float kReleaseAlpha = 0.32f;

void writeCommand(uint8_t command) {
  Core::DisplayBus::writeCommand(
      Core::Hardware::kUnusedSmallDisplayChipSelectPin, command);
}

void writeData(uint8_t value) {
  Core::DisplayBus::writeData8(
      Core::Hardware::kUnusedSmallDisplayChipSelectPin, value);
}

float clamp01(float value) {
  if (value < 0.0f) {
    return 0.0f;
  }
  if (value > 1.0f) {
    return 1.0f;
  }
  return value;
}

}  // namespace

void PressSmallDisplay::initializeGc9d01() {
  // Exact command/data order retained from the verified first 0.99-inch
  // GC9D01 display. Only its chip-select line differs (CS=15).
  writeCommand(0xFE);
  writeCommand(0xEF);
  for (uint8_t command = 0x80; command <= 0x8F; ++command) {
    writeCommand(command);
    writeData(0xFF);
  }
  writeCommand(0x3A);
  writeData(0x05);
  writeCommand(0xEC);
  writeData(0x11);
  writeCommand(0x7E);
  writeData(0x7A);
  writeCommand(0x74);
  for (const uint8_t value : {0x02, 0x0E, 0x00, 0x00, 0x28, 0x00, 0x00}) {
    writeData(value);
  }
  writeCommand(0x98);
  writeData(0x3E);
  writeCommand(0x99);
  writeData(0x3E);
  writeCommand(0xB5);
  writeData(0x0E);
  writeData(0x0E);
  writeCommand(0x60);
  for (const uint8_t value : {0x38, 0x09, 0x6D, 0x67}) {
    writeData(value);
  }
  writeCommand(0x63);
  for (const uint8_t value : {0x38, 0xAD, 0x6D, 0x67, 0x05}) {
    writeData(value);
  }
  writeCommand(0x64);
  for (const uint8_t value : {0x38, 0x0B, 0x70, 0xAB, 0x6D, 0x67}) {
    writeData(value);
  }
  writeCommand(0x66);
  for (const uint8_t value : {0x38, 0x0F, 0x70, 0xAF, 0x6D, 0x67}) {
    writeData(value);
  }
  writeCommand(0x6A);
  writeData(0x00);
  writeData(0x00);
  writeCommand(0x68);
  for (const uint8_t value : {0x3B, 0x08, 0x04, 0x00, 0x04, 0x64, 0x67}) {
    writeData(value);
  }
  writeCommand(0x6C);
  for (const uint8_t value : {0x22, 0x02, 0x22, 0x02, 0x22, 0x22, 0x50}) {
    writeData(value);
  }
  writeCommand(0x6E);
  for (const uint8_t value : {
           0x00, 0x00, 0x00, 0x00, 0x07, 0x01, 0x13, 0x11, 0x0B, 0x09,
           0x16, 0x15, 0x1D, 0x1E, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x1D,
           0x15, 0x16, 0x0A, 0x0C, 0x12, 0x14, 0x02, 0x08, 0x00, 0x00,
           0x00, 0x00,
       }) {
    writeData(value);
  }
  writeCommand(0xA9);
  writeData(0x1B);
  writeCommand(0xA8);
  writeData(0x6B);
  writeCommand(0xA8);
  writeData(0x6D);
  writeCommand(0xA7);
  writeData(0x40);
  writeCommand(0xAD);
  writeData(0x47);
  writeCommand(0xAF);
  writeData(0x73);
  writeCommand(0xAF);
  writeData(0x73);
  writeCommand(0xAC);
  writeData(0x44);
  writeCommand(0xA3);
  writeData(0x6C);
  writeCommand(0xCB);
  writeData(0x00);
  writeCommand(0xCD);
  writeData(0x22);
  writeCommand(0xC2);
  writeData(0x10);
  writeCommand(0xC5);
  writeData(0x00);
  writeCommand(0xC6);
  writeData(0x0E);
  writeCommand(0xC7);
  writeData(0x1F);
  writeCommand(0xC8);
  writeData(0x0E);
  writeCommand(0xBF);
  writeData(0x00);
  writeCommand(0xF9);
  writeData(0x20);
  writeCommand(0x9B);
  writeData(0x3B);
  writeCommand(0x93);
  for (const uint8_t value : {0x33, 0x7F, 0x00}) {
    writeData(value);
  }
  writeCommand(0x70);
  for (const uint8_t value : {0x0E, 0x0F, 0x03, 0x0E, 0x0F, 0x03}) {
    writeData(value);
  }
  writeCommand(0x71);
  for (const uint8_t value : {0x0E, 0x16, 0x03}) {
    writeData(value);
  }
  writeCommand(0x91);
  writeData(0x0E);
  writeData(0x09);
  writeCommand(0xC3);
  writeData(0x2C);
  writeCommand(0xC4);
  writeData(0x1A);
  writeCommand(0xF0);
  for (const uint8_t value : {0x51, 0x13, 0x0C, 0x06, 0x00, 0x2F}) {
    writeData(value);
  }
  writeCommand(0xF2);
  for (const uint8_t value : {0x51, 0x13, 0x0C, 0x06, 0x00, 0x33}) {
    writeData(value);
  }
  writeCommand(0xF1);
  for (const uint8_t value : {0x3C, 0x94, 0x4F, 0x33, 0x34, 0xCF}) {
    writeData(value);
  }
  writeCommand(0xF3);
  for (const uint8_t value : {0x4D, 0x94, 0x4F, 0x33, 0x34, 0xCF}) {
    writeData(value);
  }
  writeCommand(0x36);
  // MADCTL: retain the verified color order and rotate this 40x160 panel
  // 180 degrees (MX | MY), so the physical mounting orientation is upright.
  writeData(0xC0);
  writeCommand(0x11);
  delay(200);
  writeCommand(0x29);
  writeCommand(0x51);
  writeData(kDisplayBrightness);
  writeCommand(0x53);
  writeData(kBrightnessControlEnabled);
  writeCommand(0x2C);
}

void PressSmallDisplay::setAddress(uint16_t x1, uint16_t y1, uint16_t x2,
                                   uint16_t y2) {
  Core::DisplayBus::setAddressWindow(
      Core::Hardware::kUnusedSmallDisplayChipSelectPin, x1, y1, x2, y2);
}

void PressSmallDisplay::fillRectangle(uint16_t x, uint16_t y, uint16_t width,
                                      uint16_t height, uint16_t color) {
  if (width == 0U || height == 0U || x >= kWidth || y >= kHeight) {
    return;
  }
  const uint16_t clippedWidth = min<uint16_t>(width, kWidth - x);
  const uint16_t clippedHeight = min<uint16_t>(height, kHeight - y);
  setAddress(x, y, x + clippedWidth - 1U, y + clippedHeight - 1U);
  const uint32_t pixels = static_cast<uint32_t>(clippedWidth) * clippedHeight;
  for (uint32_t index = 0; index < pixels; ++index) {
    Core::DisplayBus::writeData16(
        Core::Hardware::kUnusedSmallDisplayChipSelectPin, color);
  }
}

void PressSmallDisplay::drawScaleElements(uint16_t yStart, uint16_t yEnd) {
  const uint16_t clippedStart = max<uint16_t>(yStart, kScaleTopY);
  const uint16_t clippedEnd = min<uint16_t>(yEnd, kScaleBottomY + 1U);
  if (clippedStart >= clippedEnd) {
    return;
  }

  fillRectangle(kAxisX, clippedStart, 1, clippedEnd - clippedStart, kGrey);
  for (uint8_t index = 0; index <= kTickIntervals; ++index) {
    const uint16_t tickY = kScaleTopY +
                           static_cast<uint16_t>(
                               (kScaleBottomY - kScaleTopY) * index /
                               kTickIntervals);
    if (tickY < clippedStart || tickY >= clippedEnd) {
      continue;
    }
    const uint16_t tickLength = (index % 2U) == 0U ? kMajorTickLength
                                                    : kMinorTickLength;
    fillRectangle(kAxisX, tickY, tickLength, 1, kGrey);
  }
}

void PressSmallDisplay::drawMeterBackground() {
  fillRectangle(0, 0, kWidth, kHeight, kWhite);
  drawScaleElements(kScaleTopY, kScaleBottomY + 1U);
}

void PressSmallDisplay::restorePointerBackground(uint16_t pointerY) {
  fillRectangle(0, pointerY, kWidth, kPointerHeight, kWhite);
  drawScaleElements(pointerY, pointerY + kPointerHeight);
}

void PressSmallDisplay::drawPointer(uint16_t pointerY) {
  fillRectangle(kPointerX, pointerY, kPointerWidth, kPointerHeight, kRed);
}

uint16_t PressSmallDisplay::strengthToPointerY(float strength) const {
  const float clamped = clamp01(strength);
  return static_cast<uint16_t>(lroundf(
      static_cast<float>(kScaleBottomY) -
      clamped * static_cast<float>(kScaleBottomY - kScaleTopY)));
}

void PressSmallDisplay::begin() {
  if (initialized_) {
    return;
  }

  Core::DisplayBus::Transaction transaction;
  initializeGc9d01();
  drawMeterBackground();
  pointerY_ = strengthToPointerY(0.0f);
  drawPointer(pointerY_);
  pointerDrawn_ = true;
  initialized_ = true;
  Serial.println("[DISPLAY] GC9D01 pressure meter initialized on CS=15");
}

void PressSmallDisplay::updatePressStrength(uint16_t adcValue) {
  if (!initialized_) {
    return;
  }

  const uint16_t clampedAdc = min<uint16_t>(adcValue, kIdleAdc);
  const float targetStrength = clamp01(
      static_cast<float>(kIdleAdc - clampedAdc) /
      static_cast<float>(kIdleAdc - kFullPressAdc));
  const float alpha = targetStrength > smoothedStrength_ ? kAttackAlpha
                                                          : kReleaseAlpha;
  smoothedStrength_ += alpha * (targetStrength - smoothedStrength_);
  const uint16_t nextPointerY = strengthToPointerY(smoothedStrength_);
  if (pointerDrawn_ && nextPointerY == pointerY_) {
    return;
  }

  Core::DisplayBus::Transaction transaction;
  if (pointerDrawn_) {
    restorePointerBackground(pointerY_);
  }
  drawPointer(nextPointerY);
  pointerY_ = nextPointerY;
  pointerDrawn_ = true;
}

}  // namespace Display
