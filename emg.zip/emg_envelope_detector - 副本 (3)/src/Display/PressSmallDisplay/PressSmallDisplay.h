#pragma once

#include <Arduino.h>

namespace Display {

// The second 0.99-inch GC9D01 display (CS=15). It is a display-only pressure
// meter fed by the micro-motion sensor's already sampled ADC value.
class PressSmallDisplay {
 public:
  void begin();
  void updatePressStrength(uint16_t adcValue);

 private:
  void initializeGc9d01();
  void setAddress(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);
  void fillRectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height,
                     uint16_t color);
  void drawMeterBackground();
  void drawScaleElements(uint16_t yStart, uint16_t yEnd);
  void restorePointerBackground(uint16_t pointerY);
  void drawPointer(uint16_t pointerY);
  uint16_t strengthToPointerY(float strength) const;

  bool initialized_ = false;
  bool pointerDrawn_ = false;
  float smoothedStrength_ = 0.0f;
  uint16_t pointerY_ = 0;
};

}  // namespace Display
