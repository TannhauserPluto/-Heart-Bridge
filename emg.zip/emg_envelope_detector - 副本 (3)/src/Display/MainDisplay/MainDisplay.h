#pragma once

#include <Arduino.h>

namespace Display {

// Directly encapsulates the verified ST7789 diagnostic implementation.  Its
// pin assignments and controller command order deliberately remain unchanged.
class MainDisplay {
 public:
  void begin();
  void update();

  void showBoot();
  void showCalibration();
  void showIdle();
  void showNeedPrompt();
  void showScanningNeed(const char* needText);
  void showConfirmation(const char* needText);
  void showCallingFamily();
  void showRequestSent();
  void showCancelled();
 void showError();

 private:
  enum class RenderPhase : uint8_t {
    IDLE,
    RENDERING,
  };

  enum class Page : uint8_t {
    BOOT,
    CALIBRATION,
    IDLE,
    NEED_PROMPT,
    NEED_SCAN,
    CONFIRMATION,
    CALLING_FAMILY,
    REQUEST_SENT,
    CANCELLED,
    ERROR,
  };

  void resetPanel();
  void initializeSt7789FromStm32Example();
  void setPage(Page page, const char* selectionText = nullptr);
  void renderCurrentPage();
  void drawPageFrame(const char* statusText);
  void drawFooterHint(const char* firstLine, const char* secondLine = nullptr);
  void drawHeroText(const char* text, uint16_t y);
  void drawSelectionCard(const char* needText, uint16_t y);
  void drawText(const char* text, uint16_t x, uint16_t y, uint8_t scale,
                uint16_t color);
  void drawTextCentered(const char* text, uint16_t centerX, uint16_t y,
                        uint8_t scale, uint16_t color);
  void drawTextRight(const char* text, uint16_t rightX, uint16_t y,
                     uint8_t scale, uint16_t color);
  void drawGlyph(uint16_t codepoint, uint16_t x, uint16_t y, uint8_t scale,
                 uint16_t color);
  void paintRectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height,
                      uint16_t color);
  void setAddress(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);
  void fillScreen(uint16_t color);
  void writePixel(uint16_t desiredColor);

  bool initialized_ = false;
  bool frameDrawn_ = false;
  RenderPhase renderPhase_ = RenderPhase::IDLE;
  Page page_ = Page::BOOT;
  const char* selectionText_ = nullptr;
};

}  // namespace Display
