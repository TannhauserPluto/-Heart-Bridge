#pragma once

#include <Arduino.h>

// Presentation-only tokens for the 2.8-inch main display.  Keeping these
// values together prevents the interaction pages from accumulating unrelated
// RGB565 and layout literals.
namespace Display::UiTheme {

// White / grey / restrained red, matching the two small mechanical meters.
constexpr uint16_t kBackground = 0xFFFE;
constexpr uint16_t kSurface = 0xF7BE;
constexpr uint16_t kTextPrimary = 0x39E7;
constexpr uint16_t kTextSecondary = 0x7BEF;
constexpr uint16_t kDivider = 0xD69A;
constexpr uint16_t kAccentRed = 0xC9A5;
constexpr uint16_t kAccentLight = 0xFDF3;

constexpr uint16_t kScreenWidth = 320;
constexpr uint16_t kScreenHeight = 240;
constexpr uint16_t kMarginX = 22;
constexpr uint16_t kMarginY = 16;
constexpr uint16_t kHeaderDividerY = 48;
constexpr uint16_t kFooterDividerY = 199;
constexpr uint16_t kContentLeft = kMarginX;
constexpr uint16_t kContentRight = kScreenWidth - kMarginX;
constexpr uint16_t kHeaderStatusClearLeft = 144;
constexpr uint16_t kHeaderStatusClearTop = 12;
constexpr uint16_t kHeaderStatusClearHeight = 25;

constexpr uint8_t kTitleScale = 1;
constexpr uint8_t kBodyScale = 1;
constexpr uint8_t kHeroScale = 2;

}  // namespace Display::UiTheme
