#include "MainDisplay.h"

#include <Arduino.h>

#include "ChineseFont.h"
#include "Core/DisplayBus.h"
#include "Core/Hardware.h"
#include "UiTheme.h"

namespace Display {
namespace {

// The verified panel uses a 240x320 ST7789.  MX|MV is the horizontal
// orientation opposite to MY|MV (the usual landscape orientation), i.e. the
// requested 180-degree landscape direction.  The original RGB/BGR setting is
// deliberately left untouched.
constexpr uint8_t kLandscapeRotation180Madctl = 0x60;

}  // namespace

void MainDisplay::setAddress(uint16_t x1, uint16_t y1, uint16_t x2,
                             uint16_t y2) {
  Core::DisplayBus::setAddressWindow(Core::Hardware::kMainDisplayChipSelectPin,
                                     x1, y1, x2, y2);
}

void MainDisplay::writePixel(uint16_t desiredColor) {
  // This compensation is copied unchanged from the verified diagnostic.
  Core::DisplayBus::writeData16(
      Core::Hardware::kMainDisplayChipSelectPin,
      static_cast<uint16_t>(~desiredColor));
}

void MainDisplay::fillScreen(uint16_t color) {
  setAddress(0, 0, UiTheme::kScreenWidth - 1U, UiTheme::kScreenHeight - 1U);
  for (uint16_t y = 0; y < UiTheme::kScreenHeight; ++y) {
    for (uint16_t x = 0; x < UiTheme::kScreenWidth; ++x) {
      writePixel(color);
    }
  }
}

void MainDisplay::resetPanel() {
  // Exact timing used in the known-good STM32 LCD_Init().
  digitalWrite(Core::Hardware::kMainDisplayResetPin, LOW);
  delay(30);
  digitalWrite(Core::Hardware::kMainDisplayResetPin, HIGH);
  delay(100);
  // JP4 BLK is tied to 3V3; retain the STM32 source's post-enable wait.
  delay(100);
}

void MainDisplay::initializeSt7789FromStm32Example() {
  // Direct register-for-register port of the verified STM32F103 example.
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0x11);

  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0x36);
  // Rotation is the sole permitted initialization change for this UI task.
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               kLandscapeRotation180Madctl);

  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0x3A);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0x05);

  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xB2);
  for (const uint8_t value : {0x0C, 0x0C, 0x00, 0x33, 0x33}) {
    Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                                 value);
  }

  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xB7);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0x35);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xBB);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0x35);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xC0);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0x2C);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xC2);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0x01);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xC3);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0x13);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xC4);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0x20);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xC6);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0x0F);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xD0);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0xA4);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0xA1);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xD6);
  Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                               0xA1);

  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xE0);
  for (const uint8_t value : {0xF0, 0x00, 0x04, 0x04, 0x04, 0x05, 0x29,
                              0x33, 0x3E, 0x38, 0x12, 0x12, 0x28, 0x30}) {
    Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                                 value);
  }

  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0xE1);
  for (const uint8_t value : {0xF0, 0x07, 0x0A, 0x0D, 0x0B, 0x07, 0x28,
                              0x33, 0x3E, 0x36, 0x14, 0x14, 0x29, 0x32}) {
    Core::DisplayBus::writeData8(Core::Hardware::kMainDisplayChipSelectPin,
                                 value);
  }

  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0x11);
  delay(120);
}

void MainDisplay::paintRectangle(uint16_t x, uint16_t y, uint16_t width,
                                 uint16_t height, uint16_t color) {
  if (width == 0U || height == 0U || x >= UiTheme::kScreenWidth ||
      y >= UiTheme::kScreenHeight) {
    return;
  }
  const uint16_t clippedWidth =
      min<uint16_t>(width, UiTheme::kScreenWidth - x);
  const uint16_t clippedHeight =
      min<uint16_t>(height, UiTheme::kScreenHeight - y);
  setAddress(x, y, x + clippedWidth - 1U, y + clippedHeight - 1U);
  const uint32_t pixels = static_cast<uint32_t>(clippedWidth) * clippedHeight;
  for (uint32_t index = 0; index < pixels; ++index) {
    writePixel(color);
  }
}

void MainDisplay::setPage(Page page, const char* selectionText) {
  page_ = page;
  selectionText_ = selectionText;
  // Page writes remain event-driven.  No display work is scheduled from the
  // application's steady-state loop.
  renderPhase_ = RenderPhase::RENDERING;
}

void MainDisplay::drawGlyph(uint16_t codepoint, uint16_t x, uint16_t y,
                            uint8_t scale, uint16_t color) {
  const ChineseFont::Glyph* glyph = ChineseFont::findGlyph(codepoint);
  if (glyph == nullptr) {
    return;
  }

  for (uint8_t row = 0; row < ChineseFont::kGlyphHeight; ++row) {
    const uint16_t bits = glyph->rows[row];
    uint8_t column = 0;
    while (column < ChineseFont::kGlyphWidth) {
      const uint16_t mask = static_cast<uint16_t>(1U << (15U - column));
      if ((bits & mask) == 0U) {
        ++column;
        continue;
      }
      const uint8_t startColumn = column;
      do {
        ++column;
      } while (column < ChineseFont::kGlyphWidth &&
               (bits & static_cast<uint16_t>(1U << (15U - column))) != 0U);
      paintRectangle(x + startColumn * scale, y + row * scale,
                     (column - startColumn) * scale, scale, color);
    }
  }
}

void MainDisplay::drawText(const char* text, uint16_t x, uint16_t y,
                           uint8_t scale, uint16_t color) {
  if (text == nullptr) {
    return;
  }
  uint16_t codepoint = 0;
  while (static_cast<uint8_t>(*text) != 0U) {
    text = ChineseFont::nextCodePoint(text, codepoint);
    if (codepoint != 0U) {
      drawGlyph(codepoint, x, y, scale, color);
      x += ChineseFont::kGlyphWidth * scale;
    }
  }
}

void MainDisplay::drawTextCentered(const char* text, uint16_t centerX,
                                   uint16_t y, uint8_t scale,
                                   uint16_t color) {
  const uint16_t textWidth = ChineseFont::textWidth(text, scale);
  const uint16_t x = textWidth < centerX * 2U ?
                         centerX - textWidth / 2U :
                         0U;
  drawText(text, x, y, scale, color);
}

void MainDisplay::drawTextRight(const char* text, uint16_t rightX, uint16_t y,
                                uint8_t scale, uint16_t color) {
  const uint16_t textWidth = ChineseFont::textWidth(text, scale);
  drawText(text, textWidth < rightX ? rightX - textWidth : 0U, y, scale,
           color);
}

void MainDisplay::drawPageFrame(const char* statusText) {
  // A small red status mark, fine grey rules, and generous white space echo
  // the language of the two external meter displays without copying them.
  paintRectangle(UiTheme::kMarginX, 22, 6, 6, UiTheme::kAccentRed);
  drawText("心桥", UiTheme::kMarginX + 13U, UiTheme::kMarginY,
           UiTheme::kTitleScale, UiTheme::kTextPrimary);
  drawTextRight(statusText, UiTheme::kContentRight, UiTheme::kMarginY,
                UiTheme::kTitleScale, UiTheme::kTextSecondary);
  paintRectangle(UiTheme::kContentLeft, UiTheme::kHeaderDividerY,
                 UiTheme::kContentRight - UiTheme::kContentLeft, 1,
                 UiTheme::kDivider);
  paintRectangle(UiTheme::kContentLeft, UiTheme::kFooterDividerY,
                 UiTheme::kContentRight - UiTheme::kContentLeft, 1,
                 UiTheme::kDivider);
}

void MainDisplay::drawFooterHint(const char* firstLine, const char* secondLine) {
  if (firstLine == nullptr) {
    return;
  }
  const uint16_t firstY = secondLine == nullptr ? 213U : 203U;
  drawText(firstLine, UiTheme::kMarginX, firstY, UiTheme::kBodyScale,
           UiTheme::kTextSecondary);
  if (secondLine != nullptr) {
    drawText(secondLine, UiTheme::kMarginX, 221U, UiTheme::kBodyScale,
             UiTheme::kTextSecondary);
  }
}

void MainDisplay::drawHeroText(const char* text, uint16_t y) {
  drawTextCentered(text, UiTheme::kScreenWidth / 2U, y, UiTheme::kHeroScale,
                   UiTheme::kTextPrimary);
}

void MainDisplay::drawSelectionCard(const char* needText, uint16_t y) {
  constexpr uint16_t kCardHeight = 76;
  constexpr uint16_t kAccentWidth = 4;
  const uint16_t cardWidth = UiTheme::kContentRight - UiTheme::kContentLeft;

  paintRectangle(UiTheme::kContentLeft, y, cardWidth, kCardHeight,
                 UiTheme::kSurface);
  paintRectangle(UiTheme::kContentLeft, y, kAccentWidth, kCardHeight,
                 UiTheme::kAccentRed);
  paintRectangle(UiTheme::kContentLeft + kAccentWidth, y, cardWidth - kAccentWidth,
                 1, UiTheme::kDivider);
  paintRectangle(UiTheme::kContentLeft + kAccentWidth, y + kCardHeight - 1U,
                 cardWidth - kAccentWidth, 1, UiTheme::kDivider);
  paintRectangle(UiTheme::kContentRight - 1U, y, 1, kCardHeight,
                 UiTheme::kDivider);

  const uint16_t availableWidth = cardWidth - 28U;
  const uint8_t textScale =
      ChineseFont::textWidth(needText, UiTheme::kHeroScale) <= availableWidth
          ? UiTheme::kHeroScale
          : UiTheme::kBodyScale;
  const uint16_t textHeight = ChineseFont::kGlyphHeight * textScale;
  drawTextCentered(needText, UiTheme::kScreenWidth / 2U,
                   y + (kCardHeight - textHeight) / 2U, textScale,
                   UiTheme::kTextPrimary);
}

void MainDisplay::renderCurrentPage() {
  Core::DisplayBus::Transaction transaction;
  // The controller has no page-flip framebuffer.  Keeping display output on
  // and replacing only mutable regions preserves the previous frame until
  // its replacement arrives, avoiding the visible black flash caused by
  // DISPLAY OFF (0x28) during an interaction transition.
  if (!frameDrawn_) {
    fillScreen(UiTheme::kBackground);
    frameDrawn_ = true;
  } else {
    // Header brand and both divider rules are persistent.  Only its status
    // text, the content panel, and the footer hint can differ between pages.
    paintRectangle(UiTheme::kHeaderStatusClearLeft,
                   UiTheme::kHeaderStatusClearTop,
                   UiTheme::kContentRight -
                       UiTheme::kHeaderStatusClearLeft + 1U,
                   UiTheme::kHeaderStatusClearHeight, UiTheme::kBackground);
    paintRectangle(UiTheme::kContentLeft, UiTheme::kHeaderDividerY + 1U,
                   UiTheme::kContentRight - UiTheme::kContentLeft,
                   UiTheme::kFooterDividerY - UiTheme::kHeaderDividerY - 1U,
                   UiTheme::kBackground);
    paintRectangle(UiTheme::kContentLeft, UiTheme::kFooterDividerY + 1U,
                   UiTheme::kContentRight - UiTheme::kContentLeft,
                   UiTheme::kScreenHeight - UiTheme::kFooterDividerY - 1U,
                   UiTheme::kBackground);
  }

  switch (page_) {
    case Page::BOOT:
      drawPageFrame("系统启动中");
      drawHeroText("系统启动中", 79);
      drawTextCentered("正在初始化", UiTheme::kScreenWidth / 2U, 139,
                       UiTheme::kBodyScale, UiTheme::kTextSecondary);
      break;

    case Page::CALIBRATION:
      drawPageFrame("正在校准");
      drawHeroText("正在校准", 72);
      drawText("请保持放松", UiTheme::kMarginX, 133, UiTheme::kBodyScale,
               UiTheme::kTextSecondary);
      drawText("请勿咬紧牙齿", UiTheme::kMarginX, 161, UiTheme::kBodyScale,
               UiTheme::kTextSecondary);
      break;

    case Page::IDLE:
      drawPageFrame("系统已就绪");
      drawHeroText("等待您的操作", 87);
      drawTextCentered("系统已就绪", UiTheme::kScreenWidth / 2U, 142,
                       UiTheme::kBodyScale, UiTheme::kTextSecondary);
      break;

    case Page::NEED_PROMPT:
      drawPageFrame("检测到操作");
      paintRectangle(144, 83, 32, 2, UiTheme::kAccentRed);
      drawHeroText("请问是否有需求", 101);
      drawFooterHint("再次触发  有需求", "等待超时  取消");
      break;

    case Page::NEED_SCAN:
      drawPageFrame("请选择需求");
      drawSelectionCard(selectionText_, 84);
      drawFooterHint("触发以选择");
      break;

    case Page::CONFIRMATION:
      drawPageFrame("请确认");
      drawText("您选择", UiTheme::kMarginX, 70, UiTheme::kBodyScale,
               UiTheme::kTextSecondary);
      drawSelectionCard(selectionText_, 93);
      drawFooterHint("再次触发  确认", "等待超时  返回轮询");
      break;

    case Page::CALLING_FAMILY:
      drawPageFrame("正在处理");
      drawHeroText("正在呼叫家属", 90);
      drawTextCentered("请稍候", UiTheme::kScreenWidth / 2U, 145,
                       UiTheme::kBodyScale, UiTheme::kTextSecondary);
      break;

    case Page::REQUEST_SENT:
      drawPageFrame("请求已发送");
      drawHeroText("请求已发送", 76);
      drawTextCentered("家属已收到请求", UiTheme::kScreenWidth / 2U, 133,
                       UiTheme::kBodyScale, UiTheme::kTextSecondary);
      drawTextCentered("请稍候", UiTheme::kScreenWidth / 2U, 159,
                       UiTheme::kBodyScale, UiTheme::kTextSecondary);
      break;

    case Page::CANCELLED:
      drawPageFrame("已取消");
      drawHeroText("已取消", 91);
      drawTextCentered("系统将返回待机", UiTheme::kScreenWidth / 2U, 148,
                       UiTheme::kBodyScale, UiTheme::kTextSecondary);
      break;

    case Page::ERROR:
      drawPageFrame("系统暂时不可用");
      paintRectangle(UiTheme::kMarginX, 93, 3, 54, UiTheme::kAccentRed);
      drawHeroText("系统暂时不可用", 104);
      break;
  }

  renderPhase_ = RenderPhase::IDLE;
}

void MainDisplay::begin() {
  if (initialized_) {
    return;
  }

  Serial.println("[JP4] exact STM32F103 ST7789 port starting");
  Core::DisplayBus::Transaction transaction;
  resetPanel();
  initializeSt7789FromStm32Example();
  Serial.println("[JP4] STM32 sequence: fill WHITE, then Display ON");
  fillScreen(UiTheme::kBackground);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0x20);
  Core::DisplayBus::writeCommand(Core::Hardware::kMainDisplayChipSelectPin,
                                 0x29);
  delay(20);
  initialized_ = true;
  frameDrawn_ = false;
  Serial.println("[DISPLAY] ST7789 main display initialized for interaction UI");
  showBoot();
}

void MainDisplay::update() {
  if (initialized_ && renderPhase_ == RenderPhase::RENDERING) {
    renderCurrentPage();
  }
}

void MainDisplay::showBoot() { setPage(Page::BOOT); }

void MainDisplay::showCalibration() { setPage(Page::CALIBRATION); }

void MainDisplay::showIdle() { setPage(Page::IDLE); }

void MainDisplay::showNeedPrompt() { setPage(Page::NEED_PROMPT); }

void MainDisplay::showScanningNeed(const char* needText) {
  setPage(Page::NEED_SCAN, needText);
}

void MainDisplay::showConfirmation(const char* needText) {
  setPage(Page::CONFIRMATION, needText);
}

void MainDisplay::showCallingFamily() { setPage(Page::CALLING_FAMILY); }

void MainDisplay::showRequestSent() { setPage(Page::REQUEST_SENT); }

void MainDisplay::showCancelled() { setPage(Page::CANCELLED); }

void MainDisplay::showError() { setPage(Page::ERROR); }

}  // namespace Display
