#pragma once

#include <Arduino.h>

namespace Display::ChineseFont {

constexpr uint8_t kGlyphWidth = 16;
constexpr uint8_t kGlyphHeight = 16;

struct Glyph {
  uint16_t codepoint;
  uint16_t rows[kGlyphHeight];
};

const Glyph* findGlyph(uint16_t codepoint);
const char* nextCodePoint(const char* text, uint16_t& codepoint);
uint16_t textWidth(const char* text, uint8_t scale);

}  // namespace Display::ChineseFont

