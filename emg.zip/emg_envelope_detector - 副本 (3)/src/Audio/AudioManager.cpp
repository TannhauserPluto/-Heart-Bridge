#include "AudioManager.h"

#include <LittleFS.h>
#include <M5Unified.h>

#include <cstdlib>

#include "Core/Hardware.h"

namespace Audio {
namespace {

// Cardputer Adv ES8311 control uses the same physical lines as the verified
// external display's software SPI. Only the audio devices are initialized;
// M5.begin() is intentionally not called because it also probes and takes
// ownership of the Cardputer LCD and other board resources. Codec setup is
// completed before any application panel is initialized, then every external
// display control pin is restored to the verified idle state. Playback uses
// GPIO41/42/43 only and performs no I2C traffic.
constexpr uint8_t kCodecAddress = 0x18;
constexpr int8_t kCodecSdaPin = Core::Hardware::kDisplayMosiPin;
constexpr int8_t kCodecSclPin = Core::Hardware::kDisplaySclkPin;
constexpr uint32_t kCodecI2cFrequency = 100000;
constexpr i2c_port_t kCodecI2cPort = I2C_NUM_1;
constexpr uint32_t kDiagnosticDelayMs = 30000;

constexpr int8_t kSpeakerBclkPin = 41;
constexpr int8_t kSpeakerDataPin = 42;
constexpr int8_t kSpeakerWordSelectPin = 43;
constexpr uint32_t kSpeakerOutputRate = 48000;
constexpr uint8_t kSpeakerTaskCore = 1;
constexpr uint8_t kSpeakerChannel = 0;

struct CodecRegister {
  uint8_t address;
  uint8_t value;
};

// Exact Cardputer Adv enable sequence from M5Unified 0.2.19.
constexpr CodecRegister kCodecEnableSequence[] = {
    {0x00, 0x80}, {0x01, 0xB5}, {0x02, 0x18}, {0x0D, 0x01},
    {0x12, 0x00}, {0x13, 0x10}, {0x32, 0xBF}, {0x37, 0x08},
};

bool enableCodec() {
  bool okay = true;
  for (const CodecRegister& reg : kCodecEnableSequence) {
    bool written = false;
    for (uint8_t attempt = 0; attempt < 4 && !written; ++attempt) {
      // Match M5Unified's Cardputer Adv callback exactly. In particular, use
      // writeRegister() and the same one-millisecond retry interval.
      written = M5.In_I2C.writeRegister(kCodecAddress, reg.address, &reg.value,
                                        1, kCodecI2cFrequency);
      if (!written && attempt < 3) {
        M5.delay(1);
      }
    }
    if (!written) {
      Serial.printf("[AUDIO] ES8311 write failed reg=0x%02X\n", reg.address);
      okay = false;
    }
  }
  return okay;
}

}  // namespace

VoicePrompt promptForNeed(Interaction::NeedId needId) {
  switch (needId) {
    case Interaction::NeedId::WATER:
      return VoicePrompt::NEED_WATER;
    case Interaction::NeedId::PAIN:
      return VoicePrompt::NEED_PAIN;
    case Interaction::NeedId::TURN_OVER:
      return VoicePrompt::NEED_TURN_OVER;
    case Interaction::NeedId::TOILET:
      return VoicePrompt::NEED_TOILET;
    case Interaction::NeedId::COLD:
      return VoicePrompt::NEED_COLD;
    case Interaction::NeedId::HOT:
      return VoicePrompt::NEED_HOT;
    case Interaction::NeedId::CALL_FAMILY:
      return VoicePrompt::NEED_CALL_FAMILY;
    case Interaction::NeedId::CALL_DOCTOR:
      return VoicePrompt::NEED_CALL_DOCTOR;
    case Interaction::NeedId::REST:
      return VoicePrompt::NEED_REST;
    case Interaction::NeedId::OTHER:
      return VoicePrompt::NEED_OTHER;
  }
  return VoicePrompt::NONE;
}

VoicePrompt confirmationPromptForNeed(Interaction::NeedId needId) {
  switch (needId) {
    case Interaction::NeedId::WATER:
      return VoicePrompt::CONFIRM_WATER;
    case Interaction::NeedId::PAIN:
      return VoicePrompt::CONFIRM_PAIN;
    case Interaction::NeedId::TURN_OVER:
      return VoicePrompt::CONFIRM_TURN_OVER;
    case Interaction::NeedId::TOILET:
      return VoicePrompt::CONFIRM_TOILET;
    case Interaction::NeedId::COLD:
      return VoicePrompt::CONFIRM_COLD;
    case Interaction::NeedId::HOT:
      return VoicePrompt::CONFIRM_HOT;
    case Interaction::NeedId::CALL_FAMILY:
      return VoicePrompt::CONFIRM_CALL_FAMILY;
    case Interaction::NeedId::CALL_DOCTOR:
      return VoicePrompt::CONFIRM_CALL_DOCTOR;
    case Interaction::NeedId::REST:
      return VoicePrompt::CONFIRM_REST;
    case Interaction::NeedId::OTHER:
      return VoicePrompt::CONFIRM_OTHER;
  }
  return VoicePrompt::NONE;
}

const char* AudioManager::pathForPrompt(VoicePrompt prompt) {
  switch (prompt) {
    case VoicePrompt::ASK_HAS_NEED:
      return "/voice/ask_need.wav";
    case VoicePrompt::NEED_WATER:
      return "/voice/need_water.wav";
    case VoicePrompt::NEED_PAIN:
      return "/voice/need_pain.wav";
    case VoicePrompt::NEED_TURN_OVER:
      return "/voice/need_turn_over.wav";
    case VoicePrompt::NEED_TOILET:
      return "/voice/need_toilet.wav";
    case VoicePrompt::NEED_COLD:
      return "/voice/need_cold.wav";
    case VoicePrompt::NEED_HOT:
      return "/voice/need_hot.wav";
    case VoicePrompt::NEED_CALL_FAMILY:
      return "/voice/need_call_family.wav";
    case VoicePrompt::NEED_CALL_DOCTOR:
      return "/voice/need_call_doctor.wav";
    case VoicePrompt::NEED_REST:
      return "/voice/need_rest.wav";
    case VoicePrompt::NEED_OTHER:
      return "/voice/need_other.wav";
    case VoicePrompt::CONFIRM_WATER:
      return "/voice/confirm_water.wav";
    case VoicePrompt::CONFIRM_PAIN:
      return "/voice/confirm_pain.wav";
    case VoicePrompt::CONFIRM_TURN_OVER:
      return "/voice/confirm_turn_over.wav";
    case VoicePrompt::CONFIRM_TOILET:
      return "/voice/confirm_toilet.wav";
    case VoicePrompt::CONFIRM_COLD:
      return "/voice/confirm_cold.wav";
    case VoicePrompt::CONFIRM_HOT:
      return "/voice/confirm_hot.wav";
    case VoicePrompt::CONFIRM_CALL_FAMILY:
      return "/voice/confirm_call_family.wav";
    case VoicePrompt::CONFIRM_CALL_DOCTOR:
      return "/voice/confirm_call_doctor.wav";
    case VoicePrompt::CONFIRM_REST:
      return "/voice/confirm_rest.wav";
    case VoicePrompt::CONFIRM_OTHER:
      return "/voice/confirm_other.wav";
    case VoicePrompt::CALLING_FAMILY:
      return "/voice/calling_family.wav";
    case VoicePrompt::REQUEST_SENT:
      return "/voice/request_sent.wav";
    case VoicePrompt::CANCELLED:
      return "/voice/cancelled.wav";
    case VoicePrompt::ERROR_STATE:
      return "/voice/error.wav";
    case VoicePrompt::NONE:
      return nullptr;
  }
  return nullptr;
}

bool AudioManager::verifyCodec() {
  // The audio-only initialization has already written this sequence.  Read
  // back every stable register so an I2S task starting successfully cannot be
  // mistaken for a working codec.
  bool okay = true;
  for (const CodecRegister& reg : kCodecEnableSequence) {
    // Register 0x00 is a reset command and is not guaranteed to read back as
    // the written value.  All remaining configuration registers are.
    if (reg.address == 0x00) {
      continue;
    }
    uint8_t value = 0;
    const bool read = M5.In_I2C.readRegister(
        kCodecAddress, reg.address, &value, 1, kCodecI2cFrequency);
    if (!read || value != reg.value) {
      Serial.printf("[AUDIO] ES8311 verify failed reg=0x%02X "
                    "expected=0x%02X actual=0x%02X read=%u\n",
                    reg.address, reg.value, value, read);
      okay = false;
    }
  }
  return okay;
}

void AudioManager::restoreSharedDisplayPins() {
  M5.In_I2C.release();

  // M5Unified's internal I2C controller temporarily owns GPIO8/9. Restore the
  // complete external display bus so neither a released I2C peripheral nor a
  // board probe can leave the main or auxiliary panel selected/reset.
  pinMode(Core::Hardware::kDisplaySclkPin, OUTPUT);
  pinMode(Core::Hardware::kDisplayMosiPin, OUTPUT);
  pinMode(Core::Hardware::kDisplayDataCommandPin, OUTPUT);
  pinMode(Core::Hardware::kMainDisplayResetPin, OUTPUT);
  pinMode(Core::Hardware::kMainDisplayChipSelectPin, OUTPUT);
  pinMode(Core::Hardware::kSmallDisplayChipSelectPin, OUTPUT);
  pinMode(Core::Hardware::kUnusedSmallDisplayChipSelectPin, OUTPUT);

  digitalWrite(Core::Hardware::kDisplaySclkPin, HIGH);
  digitalWrite(Core::Hardware::kDisplayMosiPin, HIGH);
  digitalWrite(Core::Hardware::kDisplayDataCommandPin, HIGH);
  digitalWrite(Core::Hardware::kMainDisplayResetPin, HIGH);
  digitalWrite(Core::Hardware::kMainDisplayChipSelectPin, HIGH);
  digitalWrite(Core::Hardware::kSmallDisplayChipSelectPin, HIGH);
  digitalWrite(Core::Hardware::kUnusedSmallDisplayChipSelectPin, HIGH);
}

bool AudioManager::begin() {
  if (initialized_) {
    return true;
  }
  diagnosticReportAtMs_ = millis() + kDiagnosticDelayMs;

  const bool i2cReady =
      M5.In_I2C.begin(kCodecI2cPort, kCodecSdaPin, kCodecSclPin);
  if (!i2cReady) {
    Serial.println("[AUDIO] ES8311 I2C initialization warning");
  }

  auto speakerConfig = M5.Speaker.config();
  speakerConfig.pin_mck = I2S_PIN_NO_CHANGE;
  speakerConfig.pin_bck = kSpeakerBclkPin;
  speakerConfig.pin_ws = kSpeakerWordSelectPin;
  speakerConfig.pin_data_out = kSpeakerDataPin;
  speakerConfig.sample_rate = kSpeakerOutputRate;
  speakerConfig.stereo = false;
  speakerConfig.buzzer = false;
  speakerConfig.use_dac = false;
  speakerConfig.magnification = 16;
  speakerConfig.task_priority = 2;
  speakerConfig.task_pinned_core = kSpeakerTaskCore;
  speakerConfig.i2s_port = I2S_NUM_1;
  M5.Speaker.config(speakerConfig);
  codecReady_ = enableCodec();
  M5.Speaker.setVolume(kVoiceVolume);
  speakerReady_ = M5.Speaker.begin();
  codecReady_ = i2cReady && codecReady_ && verifyCodec();
  restoreSharedDisplayPins();

  if (!speakerReady_) {
    Serial.println("[AUDIO] I2S speaker initialization failed; voice disabled");
    return false;
  }
  if (!codecReady_) {
    // Do not suppress normal playback because of a strict readback mismatch.
    // The audio-only codec sequence has already run and I2S is independent.
    Serial.println("[AUDIO] ES8311 verification warning; output still enabled");
  }

  // The custom partition table names the SPIFFS-subtype partition "littlefs".
  // Arduino's default label is "spiffs", which would make every WAV prompt
  // unreachable even when the 2 MiB image is correctly flashed.
  filesystemReady_ = LittleFS.begin(false, "/littlefs", 10, "littlefs");
  if (!filesystemReady_) {
    Serial.println("[AUDIO] LittleFS mount failed; WAV prompts disabled");
  }
  initialized_ = true;
  Serial.printf("[AUDIO] Hardware ready filesystem=%u volume=%u\n",
                filesystemReady_, kVoiceVolume);
  return true;
}

bool AudioManager::startPrompt(VoicePrompt prompt) {
  if (!initialized_) {
    return false;
  }

  const char* path = pathForPrompt(prompt);
  if (path == nullptr || !filesystemReady_) {
    return false;
  }

  File file = LittleFS.open(path, FILE_READ);
  if (!file) {
    Serial.printf("[AUDIO] Missing %s\n", path);
    return false;
  }
  const size_t size = file.size();
  uint8_t* buffer = static_cast<uint8_t*>(malloc(size));
  if (buffer == nullptr) {
    Serial.printf("[AUDIO] Allocation failed bytes=%u path=%s\n",
                  static_cast<unsigned>(size), path);
    return false;
  }
  const size_t bytesRead = file.read(buffer, size);
  file.close();
  if (bytesRead != size) {
    free(buffer);
    Serial.printf("[AUDIO] Short read path=%s\n", path);
    return false;
  }

  wavBuffer_ = buffer;
  wavBufferSize_ = size;
  currentPrompt_ = prompt;
  if (!M5.Speaker.playWav(wavBuffer_, wavBufferSize_, 1, kSpeakerChannel,
                          true)) {
    releaseBuffer();
    Serial.printf("[AUDIO] WAV rejected path=%s\n", path);
    return false;
  }
  state_ = PlaybackState::PLAYING;
  Serial.printf("[AUDIO] Playing %s bytes=%u\n", path,
                static_cast<unsigned>(size));
  return true;
}

bool AudioManager::play(VoicePrompt prompt) {
  if (!initialized_ || prompt == VoicePrompt::NONE) {
    return false;
  }
  if (state_ == PlaybackState::PLAYING && currentPrompt_ == prompt) {
    return true;
  }
  if (state_ == PlaybackState::STOPPING) {
    pendingPrompt_ = prompt;
    return true;
  }
  if (state_ == PlaybackState::PLAYING || M5.Speaker.isPlaying(kSpeakerChannel)) {
    pendingPrompt_ = prompt;
    M5.Speaker.stop(kSpeakerChannel);
    state_ = PlaybackState::STOPPING;
    return true;
  }
  releaseBuffer();
  return startPrompt(prompt);
}

void AudioManager::stop() {
  pendingPrompt_ = VoicePrompt::NONE;
  if (!initialized_) {
    return;
  }
  if (state_ == PlaybackState::PLAYING ||
      M5.Speaker.isPlaying(kSpeakerChannel)) {
    M5.Speaker.stop(kSpeakerChannel);
    state_ = PlaybackState::STOPPING;
  } else {
    releaseBuffer();
    state_ = PlaybackState::IDLE;
  }
}

void AudioManager::update() {
  if (!diagnosticReported_ &&
      static_cast<int32_t>(millis() - diagnosticReportAtMs_) >= 0) {
    diagnosticReported_ = true;
    Serial.printf("[AUDIO] DIAG ready=%u fs=%u codec=%u speaker=%u running=%u "
                  "volume=%u bclk=%d ws=%d data=%d\n",
                  initialized_, filesystemReady_, codecReady_, speakerReady_,
                  M5.Speaker.isRunning(), M5.Speaker.getVolume(),
                  kSpeakerBclkPin, kSpeakerWordSelectPin, kSpeakerDataPin);
  }
  if (!initialized_) {
    return;
  }
  if (state_ == PlaybackState::PLAYING) {
    if (!M5.Speaker.isPlaying(kSpeakerChannel)) {
      releaseBuffer();
      state_ = PlaybackState::IDLE;
    }
    return;
  }
  if (state_ != PlaybackState::STOPPING ||
      M5.Speaker.isPlaying(kSpeakerChannel)) {
    return;
  }

  releaseBuffer();
  state_ = PlaybackState::IDLE;
  const VoicePrompt next = pendingPrompt_;
  pendingPrompt_ = VoicePrompt::NONE;
  if (next != VoicePrompt::NONE) {
    startPrompt(next);
  }
}

bool AudioManager::isPlaying() const {
  return initialized_ &&
         (state_ != PlaybackState::IDLE ||
          M5.Speaker.isPlaying(kSpeakerChannel));
}

void AudioManager::releaseBuffer() {
  if (wavBuffer_ != nullptr) {
    free(wavBuffer_);
    wavBuffer_ = nullptr;
  }
  wavBufferSize_ = 0;
  currentPrompt_ = VoicePrompt::NONE;
}

}  // namespace Audio
