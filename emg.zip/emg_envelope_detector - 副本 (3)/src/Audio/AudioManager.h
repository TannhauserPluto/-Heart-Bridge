#pragma once

#include <Arduino.h>

#include "Interaction/NeedCatalog.h"

namespace Audio {

// Speaker_Class applies its master volume quadratically. 140 / 255 squared is
// approximately 30%, so this preserves a user-facing output level of 30%
// without making normal speech nearly inaudible.
constexpr uint8_t kVoiceVolumePercent = 30;
constexpr uint8_t kVoiceVolume = 140;

enum class VoicePrompt : uint8_t {
  ASK_HAS_NEED,
  NEED_WATER,
  NEED_PAIN,
  NEED_TURN_OVER,
  NEED_TOILET,
  NEED_COLD,
  NEED_HOT,
  NEED_CALL_FAMILY,
  NEED_CALL_DOCTOR,
  NEED_REST,
  NEED_OTHER,
  CONFIRM_WATER,
  CONFIRM_PAIN,
  CONFIRM_TURN_OVER,
  CONFIRM_TOILET,
  CONFIRM_COLD,
  CONFIRM_HOT,
  CONFIRM_CALL_FAMILY,
  CONFIRM_CALL_DOCTOR,
  CONFIRM_REST,
  CONFIRM_OTHER,
  CALLING_FAMILY,
  REQUEST_SENT,
  CANCELLED,
  ERROR_STATE,
  NONE = 0xFF,
};

VoicePrompt promptForNeed(Interaction::NeedId needId);
VoicePrompt confirmationPromptForNeed(Interaction::NeedId needId);

class AudioManager {
 public:
  bool begin();
  bool play(VoicePrompt prompt);
  void stop();
  void update();
  bool isPlaying() const;

 private:
  enum class PlaybackState : uint8_t {
    IDLE,
    PLAYING,
    STOPPING,
  };

  bool verifyCodec();
  void restoreSharedDisplayPins();
  bool startPrompt(VoicePrompt prompt);
  void releaseBuffer();
  static const char* pathForPrompt(VoicePrompt prompt);

  uint8_t* wavBuffer_ = nullptr;
  size_t wavBufferSize_ = 0;
  VoicePrompt currentPrompt_ = VoicePrompt::NONE;
  VoicePrompt pendingPrompt_ = VoicePrompt::NONE;
  PlaybackState state_ = PlaybackState::IDLE;
  bool initialized_ = false;
  bool filesystemReady_ = false;
  bool codecReady_ = false;
  bool speakerReady_ = false;
  bool diagnosticReported_ = false;
  uint32_t diagnosticReportAtMs_ = 0;
};

}  // namespace Audio
