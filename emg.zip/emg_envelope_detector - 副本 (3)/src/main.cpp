#include <Arduino.h>

#include "App/Application.h"

namespace {

App::Application application;

}  // namespace

void setup() { application.begin(); }

void loop() { application.update(); }
