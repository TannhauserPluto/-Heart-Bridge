#pragma once

#include <Arduino.h>

namespace Interaction {

// The identifiers and displayed order are restored from the pre-existing
// AAC::QuestionManager implementation.  The table is static to avoid
// allocating String/vector storage in the running firmware.
enum class NeedId : uint8_t {
  WATER,
  PAIN,
  TURN_OVER,
  TOILET,
  COLD,
  HOT,
  CALL_FAMILY,
  CALL_DOCTOR,
  REST,
  OTHER,
};

struct NeedItem {
  NeedId id;
  const char* idName;
  const char* displayText;
};

const NeedItem& firstNeed();
const NeedItem& needAt(uint8_t index);
uint8_t needCount();
uint8_t nextNeedIndex(uint8_t currentIndex);

}  // namespace Interaction
