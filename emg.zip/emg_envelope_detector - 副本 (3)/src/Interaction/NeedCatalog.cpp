#include "NeedCatalog.h"

namespace Interaction {
namespace {

// Do not change this order without an explicit interaction-flow requirement:
// it is the complete list recovered from AAC/QuestionManager.cpp.
constexpr NeedItem kNeeds[] = {
    {NeedId::WATER, "WATER", "喝水"},
    {NeedId::PAIN, "PAIN", "疼痛"},
    {NeedId::TURN_OVER, "TURN_OVER", "翻身"},
    {NeedId::TOILET, "TOILET", "上厕所"},
    {NeedId::COLD, "COLD", "我冷"},
    {NeedId::HOT, "HOT", "我热"},
    {NeedId::CALL_FAMILY, "CALL_FAMILY", "呼叫家属"},
    {NeedId::CALL_DOCTOR, "CALL_DOCTOR", "呼叫医生"},
    {NeedId::REST, "REST", "休息"},
    {NeedId::OTHER, "OTHER", "其他"},
};

constexpr uint8_t kNeedCount = sizeof(kNeeds) / sizeof(kNeeds[0]);

}  // namespace

const NeedItem& firstNeed() { return kNeeds[0]; }

const NeedItem& needAt(uint8_t index) {
  return kNeeds[index < kNeedCount ? index : 0U];
}

uint8_t needCount() { return kNeedCount; }

uint8_t nextNeedIndex(uint8_t currentIndex) {
  return static_cast<uint8_t>((currentIndex + 1U) % kNeedCount);
}

}  // namespace Interaction
