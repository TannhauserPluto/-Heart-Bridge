#pragma once

#include <Arduino.h>

#include "Interaction/NeedCatalog.h"

namespace Interaction {

// State names intentionally correspond to the recovered legacy flow:
// IDLE -> TRIGGER_CONFIRM -> NEED_SCAN -> OPTION_CONFIRM -> ACTION_EXECUTE
// -> FEEDBACK -> IDLE.  BOOT/CALIBRATING/CANCELLED provide display-only
// lifecycle feedback without changing the legacy user decisions.
enum class State : uint8_t {
  BOOT,
  CALIBRATING,
  IDLE,
  ASK_HAS_NEED,
  SCAN_NEEDS,
  CONFIRM_NEED,
  CALLING_FAMILY,
  REQUEST_SENT,
  CANCELLED,
  ERROR_STATE,
};

struct UpdateResult {
  bool stateChanged = false;
  bool selectionChanged = false;
  bool requestCreated = false;
};

class InteractionStateMachine {
 public:
  void begin(uint32_t nowMs);
  UpdateResult update(uint32_t nowMs, bool emgReady, bool triggerEvent);
  // Presentation-flow escape only: it never changes the EMG detector or its
  // calibration.  It lets the application enter the normal idle flow when
  // the user has explicitly requested the micro-input fallback.
  UpdateResult bypassCalibrationForSession(uint32_t nowMs);

  State state() const;
  const NeedItem& currentNeed() const;

 private:
  void transitionTo(State nextState, uint32_t nowMs);
  void logStateTransition(State previous, State next) const;
  void logScan() const;
  static const char* stateName(State state);
  static bool elapsed(uint32_t nowMs, uint32_t startedMs, uint32_t intervalMs);

  State state_ = State::BOOT;
  uint32_t stateStartedMs_ = 0;
  uint32_t lastScanMs_ = 0;
  uint8_t needIndex_ = 0;
  bool calibrationBypassedForSession_ = false;
  UpdateResult update_;
};

}  // namespace Interaction
