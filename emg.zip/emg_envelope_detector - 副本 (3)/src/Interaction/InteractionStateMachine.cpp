#include "InteractionStateMachine.h"

#include "Core/Config.h"

namespace Interaction {

void InteractionStateMachine::begin(uint32_t nowMs) {
  state_ = State::BOOT;
  stateStartedMs_ = nowMs;
  lastScanMs_ = nowMs;
  needIndex_ = 0;
  calibrationBypassedForSession_ = false;
  update_ = {};
  if (Core::Config::kAppDebugLogging) {
    Serial.printf("[APP] %s\n", stateName(state_));
  }
}

UpdateResult InteractionStateMachine::update(uint32_t nowMs, bool emgReady,
                                              bool triggerEvent) {
  update_ = {};

  // Detection readiness is read-only information from EMGDetector.  It does
  // not alter calibration or any detector state.
  if (!emgReady && !calibrationBypassedForSession_ &&
      state_ != State::BOOT && state_ != State::CALIBRATING) {
    transitionTo(State::CALIBRATING, nowMs);
    return update_;
  }

  switch (state_) {
    case State::BOOT:
      if (elapsed(nowMs, stateStartedMs_, Core::Config::kBootScreenDurationMs)) {
        transitionTo(emgReady ? State::IDLE : State::CALIBRATING, nowMs);
      }
      break;

    case State::CALIBRATING:
      if (emgReady) {
        transitionTo(State::IDLE, nowMs);
      }
      break;

    case State::IDLE:
      if (triggerEvent) {
        Serial.println("[EMG] TRIGGER_EVENT");
        transitionTo(State::ASK_HAS_NEED, nowMs);
      }
      break;

    case State::ASK_HAS_NEED:
      if (triggerEvent) {
        Serial.println("[INPUT] Confirm YES");
        needIndex_ = 0;
        transitionTo(State::SCAN_NEEDS, nowMs);
      } else if (elapsed(nowMs, stateStartedMs_, Core::Config::kPromptTimeoutMs)) {
        Serial.println("[INPUT] Confirm timeout -> NO");
        transitionTo(State::CANCELLED, nowMs);
      }
      break;

    case State::SCAN_NEEDS:
      if (triggerEvent) {
        Serial.printf("[INPUT] Selected %s\n", currentNeed().idName);
        transitionTo(State::CONFIRM_NEED, nowMs);
      } else if (elapsed(nowMs, lastScanMs_,
                         Core::Config::kNeedScanIntervalMs)) {
        lastScanMs_ += Core::Config::kNeedScanIntervalMs;
        // Rebase after a very long display transaction without emitting a
        // burst of skipped scan changes.
        if (elapsed(nowMs, lastScanMs_, Core::Config::kNeedScanIntervalMs)) {
          lastScanMs_ = nowMs;
        }
        needIndex_ = nextNeedIndex(needIndex_);
        update_.selectionChanged = true;
        logScan();
      }
      break;

    case State::CONFIRM_NEED:
      if (triggerEvent) {
        Serial.println("[INPUT] Confirm YES");
        transitionTo(State::CALLING_FAMILY, nowMs);
        update_.requestCreated = true;
      } else if (elapsed(nowMs, stateStartedMs_,
                         Core::Config::kConfirmationTimeoutMs)) {
        Serial.println("[INPUT] Confirm timeout -> NEED_SCAN");
        transitionTo(State::SCAN_NEEDS, nowMs);
      }
      break;

    case State::CALLING_FAMILY:
      if (elapsed(nowMs, stateStartedMs_,
                  Core::Config::kCallingFamilyDurationMs)) {
        transitionTo(State::REQUEST_SENT, nowMs);
      }
      break;

    case State::REQUEST_SENT:
      // Retains the legacy FEEDBACK display interval, which also serves as
      // the post-request cool-down before resetting the selection.
      if (elapsed(nowMs, stateStartedMs_,
                  Core::Config::kRequestSentDurationMs)) {
        needIndex_ = 0;
        transitionTo(State::IDLE, nowMs);
      }
      break;

    case State::CANCELLED:
      if (elapsed(nowMs, stateStartedMs_,
                  Core::Config::kCancelledScreenDurationMs)) {
        transitionTo(State::IDLE, nowMs);
      }
      break;

    case State::ERROR_STATE:
      // Error recovery is intentionally not synthesized.  A real future
      // hardware/service fault may transition out through an explicit API.
      break;
  }

  return update_;
}

UpdateResult InteractionStateMachine::bypassCalibrationForSession(
    uint32_t nowMs) {
  update_ = {};
  if (state_ != State::CALIBRATING) {
    return update_;
  }

  calibrationBypassedForSession_ = true;
  transitionTo(State::IDLE, nowMs);
  return update_;
}

State InteractionStateMachine::state() const { return state_; }

const NeedItem& InteractionStateMachine::currentNeed() const {
  return needAt(needIndex_);
}

void InteractionStateMachine::transitionTo(State nextState, uint32_t nowMs) {
  const State previous = state_;
  state_ = nextState;
  stateStartedMs_ = nowMs;
  update_.stateChanged = true;
  logStateTransition(previous, nextState);

  if (state_ == State::SCAN_NEEDS) {
    lastScanMs_ = nowMs;
    update_.selectionChanged = true;
    logScan();
  }
}

void InteractionStateMachine::logStateTransition(State previous, State next) const {
  if (Core::Config::kAppDebugLogging) {
    Serial.printf("[APP] %s -> %s\n", stateName(previous), stateName(next));
  }
}

void InteractionStateMachine::logScan() const {
  if (Core::Config::kAppDebugLogging) {
    Serial.printf("[SCAN] index=%u text=%s\n", needIndex_,
                  currentNeed().idName);
  }
}

const char* InteractionStateMachine::stateName(State state) {
  switch (state) {
    case State::BOOT:
      return "BOOT";
    case State::CALIBRATING:
      return "CALIBRATING";
    case State::IDLE:
      return "IDLE";
    case State::ASK_HAS_NEED:
      return "ASK_HAS_NEED";
    case State::SCAN_NEEDS:
      return "SCAN_NEEDS";
    case State::CONFIRM_NEED:
      return "CONFIRM_NEED";
    case State::CALLING_FAMILY:
      return "CALLING_FAMILY";
    case State::REQUEST_SENT:
      return "REQUEST_SENT";
    case State::CANCELLED:
      return "CANCELLED";
    case State::ERROR_STATE:
      return "ERROR_STATE";
  }
  return "UNKNOWN";
}

bool InteractionStateMachine::elapsed(uint32_t nowMs, uint32_t startedMs,
                                      uint32_t intervalMs) {
  return nowMs - startedMs >= intervalMs;
}

}  // namespace Interaction
