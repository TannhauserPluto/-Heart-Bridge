#include "MicroMotionSensor.h"

namespace Input {
namespace {

// Cardputer G1 (ESP32-S3 GPIO1) is a dedicated external port pin. GPIO5 is
// wired to the Cardputer keyboard matrix and cannot provide a stable sensor
// input.
constexpr uint8_t kHsS71PySignalPin = 1;
// Determined by the G1 diagnostic: idle is near 4095, while touch is 100-300.
constexpr uint16_t kAnalogTriggerThreshold = 1500;
// Match the independent demo's display/sample cadence. Ten ADC conversions per
// second keep this auxiliary sensor out of the EMG 500 Hz sampling path.
constexpr uint32_t kSampleIntervalMs = 100;
constexpr uint32_t kReleaseStableMs = 50;

bool elapsed(uint32_t nowMs, uint32_t startedMs, uint32_t intervalMs) {
  return nowMs - startedMs >= intervalMs;
}

}  // namespace

void MicroMotionSensor::begin() {
  if (initialized_) {
    return;
  }

  pinMode(kHsS71PySignalPin, INPUT);
  analogReadResolution(12);
  analogSetPinAttenuation(kHsS71PySignalPin, ADC_11db);
  latestAdc_ = static_cast<uint16_t>(analogRead(kHsS71PySignalPin));
  active_ = isAdcActive(latestAdc_);
  lastSampleMs_ = millis();
  initialized_ = true;
  Serial.printf("[MICRO] HS-S71-PY ready GPIO=%u adc_trigger_lt=%u initial_adc=%u\n",
                kHsS71PySignalPin, kAnalogTriggerThreshold, latestAdc_);
}

void MicroMotionSensor::update(uint32_t nowMs) {
  if (!initialized_) {
    return;
  }

  if (!elapsed(nowMs, lastSampleMs_, kSampleIntervalMs)) {
    return;
  }
  lastSampleMs_ = nowMs;
  latestAdc_ = static_cast<uint16_t>(analogRead(kHsS71PySignalPin));
  const bool signalActive = isAdcActive(latestAdc_);
  if (signalActive) {
    releaseCandidate_ = false;
    if (!active_) {
      active_ = true;
      triggerPending_ = true;
      Serial.printf("[MICRO] TRIGGER adc=%u\n", latestAdc_);
    }
    return;
  }

  if (!active_) {
    return;
  }

  // The source example has no debounce.  A short non-blocking stable-release
  // requirement prevents contact bounce from rearming a held physical action.
  if (!releaseCandidate_) {
    releaseCandidate_ = true;
    releaseStartedMs_ = nowMs;
    return;
  }
  if (elapsed(nowMs, releaseStartedMs_, kReleaseStableMs)) {
    active_ = false;
    releaseCandidate_ = false;
#if defined(MICRO_SENSOR_DEBUG) && MICRO_SENSOR_DEBUG
    Serial.printf("[MICRO] RELEASED adc=%u\n", latestAdc_);
#endif
  }
}

bool MicroMotionSensor::consumeTrigger() {
  const bool trigger = triggerPending_;
  triggerPending_ = false;
  return trigger;
}

bool MicroMotionSensor::isActive() const { return active_; }

uint16_t MicroMotionSensor::latestAdc() const { return latestAdc_; }

bool MicroMotionSensor::isAdcActive(uint16_t adcValue) const {
  return adcValue < kAnalogTriggerThreshold;
}

}  // namespace Input
