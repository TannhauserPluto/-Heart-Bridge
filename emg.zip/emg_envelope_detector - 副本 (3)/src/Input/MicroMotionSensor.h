#pragma once

#include <Arduino.h>

namespace Input {

// HS-S71-PY integration: the validated Cardputer G1 diagnostic observes an
// analog signal that is active below the selected ADC threshold.  This class
// intentionally knows nothing about EMG, displays or interaction states; it
// turns one physical active/release cycle into one event.
class MicroMotionSensor {
 public:
  void begin();
  void update(uint32_t nowMs);
  bool consumeTrigger();
  bool isActive() const;
  uint16_t latestAdc() const;

 private:
  bool isAdcActive(uint16_t adcValue) const;

  bool initialized_ = false;
  bool active_ = false;
  bool triggerPending_ = false;
  bool releaseCandidate_ = false;
  uint16_t latestAdc_ = 4095;
  uint32_t lastSampleMs_ = 0;
  uint32_t releaseStartedMs_ = 0;
};

}  // namespace Input
