#pragma once

#include <Arduino.h>

namespace Core::Hardware {

// These values are the verified transfer-board connections.  They are kept in
// one place so no display module can silently claim a different SPI signal.
constexpr int8_t kDisplaySclkPin = 9;
constexpr int8_t kDisplayMosiPin = 8;
constexpr int8_t kDisplayDataCommandPin = 40;
constexpr int8_t kMainDisplayResetPin = 4;
constexpr int8_t kMainDisplayChipSelectPin = 13;
constexpr int8_t kSmallDisplayChipSelectPin = 14;
constexpr int8_t kUnusedSmallDisplayChipSelectPin = 15;
constexpr uint32_t kSerialBaudRate = 460800;

// Initializes only shared board resources.  It is idempotent.
void begin();

}  // namespace Core::Hardware
