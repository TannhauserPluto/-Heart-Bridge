#include "DisplayBus.h"

#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <soc/gpio_struct.h>

#include "Hardware.h"

namespace Core {
namespace {

StaticSemaphore_t displayBusMutexStorage;
SemaphoreHandle_t displayBusMutex = nullptr;

// Keep the verified wiring and waveform order while removing Arduino
// digitalWrite() overhead from the display data path.
constexpr uint32_t kClockMask = 1UL << Hardware::kDisplaySclkPin;
constexpr uint32_t kMosiMask = 1UL << Hardware::kDisplayMosiPin;
constexpr uint32_t kDataCommandMask =
    1UL << (Hardware::kDisplayDataCommandPin - 32);

inline void setLowBank(uint32_t mask) { GPIO.out_w1ts = mask; }

inline void clearLowBank(uint32_t mask) { GPIO.out_w1tc = mask; }

inline void setDataMode() { GPIO.out1_w1ts.val = kDataCommandMask; }

inline void setCommandMode() { GPIO.out1_w1tc.val = kDataCommandMask; }

}  // namespace

void DisplayBus::begin() {
  if (displayBusMutex == nullptr) {
    displayBusMutex = xSemaphoreCreateMutexStatic(&displayBusMutexStorage);
  }
}

DisplayBus::Transaction::Transaction() {
  DisplayBus::begin();
  xSemaphoreTake(displayBusMutex, portMAX_DELAY);
}

DisplayBus::Transaction::~Transaction() { xSemaphoreGive(displayBusMutex); }

void DisplayBus::writeByte(int8_t chipSelectPin, uint8_t data) {
  const uint32_t chipSelectMask =
      1UL << static_cast<uint8_t>(chipSelectPin);
  clearLowBank(chipSelectMask);
  for (uint8_t bit = 0; bit < 8; ++bit) {
    clearLowBank(kClockMask);
    if ((data & 0x80U) != 0U) {
      setLowBank(kMosiMask);
    } else {
      clearLowBank(kMosiMask);
    }
    setLowBank(kClockMask);
    data <<= 1U;
  }
  setLowBank(chipSelectMask);
}

void DisplayBus::writeCommand(int8_t chipSelectPin, uint8_t command) {
  setCommandMode();
  writeByte(chipSelectPin, command);
  setDataMode();
}

void DisplayBus::writeData8(int8_t chipSelectPin, uint8_t data) {
  writeByte(chipSelectPin, data);
}

void DisplayBus::writeData16(int8_t chipSelectPin, uint16_t data) {
  writeByte(chipSelectPin, static_cast<uint8_t>(data >> 8U));
  writeByte(chipSelectPin, static_cast<uint8_t>(data & 0xFFU));
}

void DisplayBus::setAddressWindow(int8_t chipSelectPin, uint16_t x1,
                                  uint16_t y1, uint16_t x2, uint16_t y2) {
  writeCommand(chipSelectPin, 0x2A);
  writeData16(chipSelectPin, x1);
  writeData16(chipSelectPin, x2);
  writeCommand(chipSelectPin, 0x2B);
  writeData16(chipSelectPin, y1);
  writeData16(chipSelectPin, y2);
  writeCommand(chipSelectPin, 0x2C);
}

}  // namespace Core
