#pragma once

#include <Arduino.h>

namespace Core::Config {

constexpr uint32_t kSmallDisplayRefreshMs = 100;
constexpr uint32_t kPressDisplayRefreshMs = 100;

// Preserved from the previously verified interaction flow in
// StateMachine/StateMachine.cpp.
constexpr uint32_t kNeedScanIntervalMs = 2000;
constexpr uint32_t kPromptTimeoutMs = 5000;
constexpr uint32_t kConfirmationTimeoutMs = 5000;
constexpr uint32_t kRequestSentDurationMs = 3000;

// Interaction presentation and input-fallback settings. None of these values
// are used by the EMG acquisition or detection algorithm.
constexpr uint32_t kBootScreenDurationMs = 1000;
constexpr uint32_t kCancelledScreenDurationMs = 2000;
constexpr uint32_t kCallingFamilyDurationMs = 1500;
constexpr uint32_t kStateInputGuardMs = 500;
constexpr uint8_t kCalibrationMicroBypassTriggerCount = 2;
constexpr uint8_t kMicroRestartTriggerCount = 4;
constexpr uint32_t kMicroRestartWindowMs = 2000;

constexpr bool kAppDebugLogging = true;

}  // namespace Core::Config
