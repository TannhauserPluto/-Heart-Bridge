#pragma once

#include <Arduino.h>

namespace Core {

// The three panels share SCLK, MOSI and DC.  A transaction owns that shared
// bus until its scope ends, guaranteeing that only one chip-select is active.
class DisplayBus {
 public:
  class Transaction {
   public:
    Transaction();
    ~Transaction();

    Transaction(const Transaction&) = delete;
    Transaction& operator=(const Transaction&) = delete;
  };

  static void begin();
  static void writeCommand(int8_t chipSelectPin, uint8_t command);
  static void writeData8(int8_t chipSelectPin, uint8_t data);
  static void writeData16(int8_t chipSelectPin, uint16_t data);
  static void setAddressWindow(int8_t chipSelectPin, uint16_t x1, uint16_t y1,
                               uint16_t x2, uint16_t y2);

 private:
  static void writeByte(int8_t chipSelectPin, uint8_t data);
};

}  // namespace Core
