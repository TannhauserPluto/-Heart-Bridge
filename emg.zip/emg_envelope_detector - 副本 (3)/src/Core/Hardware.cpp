#include "Hardware.h"

namespace Core::Hardware {
namespace {

bool initialized = false;

}  // namespace

void begin() {
  if (initialized) {
    return;
  }

  Serial.begin(kSerialBaudRate);
  delay(200);

  pinMode(kDisplaySclkPin, OUTPUT);
  pinMode(kDisplayMosiPin, OUTPUT);
  pinMode(kMainDisplayResetPin, OUTPUT);
  pinMode(kDisplayDataCommandPin, OUTPUT);
  pinMode(kMainDisplayChipSelectPin, OUTPUT);
  pinMode(kSmallDisplayChipSelectPin, OUTPUT);
  pinMode(kUnusedSmallDisplayChipSelectPin, OUTPUT);

  // This is the same idle state used by the verified ST7789 diagnostic.
  digitalWrite(kDisplaySclkPin, HIGH);
  digitalWrite(kDisplayMosiPin, HIGH);
  digitalWrite(kMainDisplayResetPin, HIGH);
  digitalWrite(kDisplayDataCommandPin, HIGH);
  digitalWrite(kMainDisplayChipSelectPin, HIGH);
  digitalWrite(kSmallDisplayChipSelectPin, HIGH);
  digitalWrite(kUnusedSmallDisplayChipSelectPin, HIGH);

  initialized = true;
  Serial.println("[HW] Shared display GPIO initialized");
}

}  // namespace Core::Hardware
