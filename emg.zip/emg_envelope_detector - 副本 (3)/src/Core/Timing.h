#pragma once

#include <Arduino.h>

namespace Core {

class PeriodicTimer {
 public:
  explicit PeriodicTimer(uint32_t intervalMs) : intervalMs_(intervalMs) {}

  void reset(uint32_t nowMs) { lastRunMs_ = nowMs - intervalMs_; }

  bool isDue(uint32_t nowMs) {
    if (nowMs - lastRunMs_ < intervalMs_) {
      return false;
    }
    lastRunMs_ += intervalMs_;
    // Rebase after a long display operation rather than attempting a burst of
    // delayed refreshes.
    if (nowMs - lastRunMs_ >= intervalMs_) {
      lastRunMs_ = nowMs;
    }
    return true;
  }

 private:
  const uint32_t intervalMs_;
  uint32_t lastRunMs_ = 0;
};

}  // namespace Core
