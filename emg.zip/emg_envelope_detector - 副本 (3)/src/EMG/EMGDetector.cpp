#include "EMGDetector.h"

#include <algorithm>
#include <cmath>

#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>

#include "EMG/Parameters.h"

namespace EMG {
namespace {

constexpr uint32_t kSampleRateHz = emg_parameters::kSampleRateHz;
constexpr uint32_t kSamplePeriodUs = 1000000UL / kSampleRateHz;
constexpr uint32_t kDecisionMs = emg_parameters::kDecisionMs;
constexpr size_t kDecisionSamples = kSampleRateHz * kDecisionMs / 1000;
constexpr size_t kEnvelopeSamples =
    kSampleRateHz * emg_parameters::kEnvelopeMs / 1000;
constexpr size_t kCalibrationFrames =
    emg_parameters::kRestCalibrationMs / kDecisionMs;
constexpr uint32_t kCalibrationMaxMs = 15000;
constexpr uint32_t kCalibrationRetryMs = 3000;
constexpr int kSignalBadFrames = 5;
constexpr int kSignalRecoveryFrames = 2500 / kDecisionMs;
constexpr int kQualityHoldoffFrames = 100 / kDecisionMs;
constexpr int kAdcLowRail = 16;
constexpr int kAdcHighRail = 4079;
constexpr int kAdcMaxFrameP2P = 3000;
constexpr int kAdcMinFrameP2P = 2;
constexpr size_t kEventQueueLength = 8;

static_assert(kDecisionSamples == 10,
              "decision frame must contain 10 samples");
static_assert(kEnvelopeSamples == 25,
              "50 ms envelope must contain 25 samples");
static_assert(kCalibrationFrames == 250,
              "5 second calibration must contain 250 frames");

enum class DetectorState : uint8_t {
  REST,
  ONSET_CANDIDATE,
  ACTIVE,
  OFFSET_CANDIDATE,
  REFRACTORY,
};

enum class DetectorSystemState : uint8_t {
  SETTLING,
  CALIBRATING,
  READY,
  SIGNAL_BAD,
  CAL_FAILED,
};

class Biquad {
 public:
  Biquad(float b0, float b1, float b2, float a1, float a2)
      : b0_(b0), b1_(b1), b2_(b2), a1_(a1), a2_(a2) {}

  float update(float input) {
    const float output = b0_ * input + z1_;
    z1_ = b1_ * input - a1_ * output + z2_;
    z2_ = b2_ * input - a2_ * output;
    return output;
  }

  void reset() {
    z1_ = 0.0f;
    z2_ = 0.0f;
  }

 private:
  float b0_;
  float b1_;
  float b2_;
  float a1_;
  float a2_;
  float z1_ = 0.0f;
  float z2_ = 0.0f;
};

struct EnvelopeSample {
  float envelope;
};

class EnvelopeExtractor {
 public:
  EnvelopeSample update(int raw) {
    // Coefficients and signal chain are retained from the existing detector.
    float filtered = notch_.update(static_cast<float>(raw));
    filtered = lowpass_.update(filtered);
    filtered = highpass_.update(filtered);
    const float rectified = fabsf(filtered);

    envelopeSum_ -= envelopeRing_[envelopeIndex_];
    envelopeRing_[envelopeIndex_] = rectified;
    envelopeSum_ += rectified;
    envelopeIndex_ = (envelopeIndex_ + 1U) % kEnvelopeSamples;
    if (envelopeCount_ < kEnvelopeSamples) {
      ++envelopeCount_;
    }
    return {envelopeSum_ / static_cast<float>(envelopeCount_)};
  }

  void reset() {
    notch_.reset();
    lowpass_.reset();
    highpass_.reset();
    for (float& value : envelopeRing_) {
      value = 0.0f;
    }
    envelopeSum_ = 0.0f;
    envelopeIndex_ = 0;
    envelopeCount_ = 0;
  }

 private:
  Biquad notch_{0.9896361754f, -1.6012649682f, 0.9896361754f,
                -1.6012649682f, 0.9792723507f};
  Biquad lowpass_{0.3913357725f, 0.7826715450f, 0.3913357725f,
                  0.3695273774f, 0.1958157127f};
  Biquad highpass_{0.8370891906f, -1.6741783811f, 0.8370891906f,
                   -1.6474599811f, 0.7008967812f};
  float envelopeRing_[kEnvelopeSamples] = {};
  float envelopeSum_ = 0.0f;
  size_t envelopeIndex_ = 0;
  size_t envelopeCount_ = 0;
};

struct QualityFrame {
  bool valid;
};

class SignalQualityGuard {
 public:
  void add(int raw) {
    minimumRaw_ = std::min(minimumRaw_, raw);
    maximumRaw_ = std::max(maximumRaw_, raw);
    if (raw <= kAdcLowRail || raw >= kAdcHighRail) {
      ++saturatedSamples_;
    }
  }

  QualityFrame finishFrame() {
    const int p2p = maximumRaw_ - minimumRaw_;
    const bool valid = saturatedSamples_ == 0 && p2p < kAdcMaxFrameP2P &&
                       p2p >= kAdcMinFrameP2P;
    minimumRaw_ = 4095;
    maximumRaw_ = 0;
    saturatedSamples_ = 0;
    return {valid};
  }

 private:
  int minimumRaw_ = 4095;
  int maximumRaw_ = 0;
  uint8_t saturatedSamples_ = 0;
};

struct CalibrationStats {
  bool valid = false;
  float center = 0.0f;
  float mad = 0.0f;
  float scale = 0.0f;
  float mean = 0.0f;
  float stddev = 0.0f;
  float p95 = 0.0f;
  float p99 = 0.0f;
  float driftRatio = INFINITY;
  float spikeRatio = 1.0f;
};

class RestCalibrator {
 public:
  void reset() {
    count_ = 0;
    sum_ = 0.0f;
    sumSquares_ = 0.0f;
  }

  void add(float envelope) {
    if (count_ >= kCalibrationFrames || !std::isfinite(envelope)) {
      return;
    }
    values_[count_++] = envelope;
    sum_ += envelope;
    sumSquares_ += envelope * envelope;
  }

  bool full() const { return count_ >= kCalibrationFrames; }

  CalibrationStats evaluate() const {
    CalibrationStats stats;
    if (!full()) {
      return stats;
    }

    float sorted[kCalibrationFrames];
    for (size_t index = 0; index < count_; ++index) {
      sorted[index] = values_[index];
    }
    std::sort(sorted, sorted + count_);
    stats.center = medianSorted(sorted, count_);
    stats.p95 = percentileSorted(sorted, count_, 0.95f);
    stats.p99 = percentileSorted(sorted, count_, 0.99f);
    stats.mean = sum_ / static_cast<float>(count_);
    const float variance =
        (sumSquares_ - sum_ * sum_ / static_cast<float>(count_)) /
        static_cast<float>(count_ - 1U);
    stats.stddev = sqrtf(std::max(0.0f, variance));

    float deviations[kCalibrationFrames];
    for (size_t index = 0; index < count_; ++index) {
      deviations[index] = fabsf(values_[index] - stats.center);
    }
    std::sort(deviations, deviations + count_);
    stats.mad = medianSorted(deviations, count_);
    stats.scale = std::max(
        std::max(1.4826f * stats.mad, 0.20f * stats.center), 0.5f);

    float firstHalf[kCalibrationFrames / 2U];
    float secondHalf[kCalibrationFrames / 2U];
    for (size_t index = 0; index < kCalibrationFrames / 2U; ++index) {
      firstHalf[index] = values_[index];
      secondHalf[index] = values_[index + kCalibrationFrames / 2U];
    }
    std::sort(firstHalf, firstHalf + kCalibrationFrames / 2U);
    std::sort(secondHalf, secondHalf + kCalibrationFrames / 2U);
    const float firstMedian = medianSorted(firstHalf, kCalibrationFrames / 2U);
    const float secondMedian =
        medianSorted(secondHalf, kCalibrationFrames / 2U);
    stats.driftRatio =
        fabsf(firstMedian - secondMedian) / std::max(stats.center, 1.0f);

    size_t spikeCount = 0;
    const float spikeThreshold = stats.center + 6.0f * stats.scale;
    for (size_t index = 0; index < count_; ++index) {
      if (values_[index] > spikeThreshold) {
        ++spikeCount;
      }
    }
    stats.spikeRatio =
        static_cast<float>(spikeCount) / static_cast<float>(count_);
    stats.valid =
        std::isfinite(stats.center) && std::isfinite(stats.scale) &&
        stats.center > 0.0f && stats.scale > 0.0f &&
        stats.driftRatio <= 0.20f && stats.spikeRatio <= 0.05f &&
        stats.p99 <= stats.center + 8.0f * stats.scale;
    return stats;
  }

 private:
  static float medianSorted(const float* sorted, size_t count) {
    const size_t middle = count / 2U;
    if (count & 1U) {
      return sorted[middle];
    }
    return 0.5f * (sorted[middle - 1U] + sorted[middle]);
  }

  static float percentileSorted(const float* sorted, size_t count,
                                float fraction) {
    const float position = fraction * static_cast<float>(count - 1U);
    const size_t lower = static_cast<size_t>(floorf(position));
    const size_t upper = static_cast<size_t>(ceilf(position));
    const float weight = position - static_cast<float>(lower);
    return sorted[lower] * (1.0f - weight) + sorted[upper] * weight;
  }

  float values_[kCalibrationFrames] = {};
  size_t count_ = 0;
  float sum_ = 0.0f;
  float sumSquares_ = 0.0f;
};

class DoubleThresholdDetector {
 public:
  void reset() {
    state_ = DetectorState::REST;
    binaryState_ = false;
    biteEvent_ = false;
    onsetPasses_ = 0;
    onsetFailures_ = 0;
    offsetFrames_ = 0;
    activeFrames_ = 0;
    refractoryFrames_ = 0;
    releaseFrames_ = 0;
    releaseRequiredAfterTimeout_ = false;
  }

  void update(float normalized) {
    biteEvent_ = false;
    switch (state_) {
      case DetectorState::REST:
        binaryState_ = false;
        if (normalized >= emg_parameters::kHigh) {
          state_ = DetectorState::ONSET_CANDIDATE;
          onsetPasses_ = 1;
          onsetFailures_ = 0;
        }
        break;

      case DetectorState::ONSET_CANDIDATE:
        binaryState_ = false;
        if (normalized >= emg_parameters::kHigh) {
          ++onsetPasses_;
          onsetFailures_ = 0;
        } else {
          ++onsetFailures_;
          if (onsetFailures_ > emg_parameters::kAllowedFailureFrames) {
            state_ = DetectorState::REST;
            onsetPasses_ = 0;
            onsetFailures_ = 0;
          }
        }
        if (state_ == DetectorState::ONSET_CANDIDATE &&
            onsetPasses_ >=
                emg_parameters::kOnsetMs / static_cast<int>(kDecisionMs)) {
          state_ = DetectorState::ACTIVE;
          binaryState_ = true;
          biteEvent_ = true;
          activeFrames_ = 1;
          offsetFrames_ = 0;
        }
        break;

      case DetectorState::ACTIVE:
        binaryState_ = true;
        ++activeFrames_;
        if (activeFrames_ >=
            emg_parameters::kTimeoutMs / static_cast<int>(kDecisionMs)) {
          enterTimeout();
        } else if (normalized < emg_parameters::kLow) {
          state_ = DetectorState::OFFSET_CANDIDATE;
          offsetFrames_ = 1;
        }
        break;

      case DetectorState::OFFSET_CANDIDATE:
        binaryState_ = true;
        ++activeFrames_;
        if (activeFrames_ >=
            emg_parameters::kTimeoutMs / static_cast<int>(kDecisionMs)) {
          enterTimeout();
        } else if (normalized < emg_parameters::kLow) {
          ++offsetFrames_;
          if (offsetFrames_ >=
              emg_parameters::kOffsetMs / static_cast<int>(kDecisionMs)) {
            binaryState_ = false;
            state_ = DetectorState::REFRACTORY;
            refractoryFrames_ = 0;
            releaseFrames_ = offsetFrames_;
            releaseRequiredAfterTimeout_ = false;
          }
        } else {
          state_ = DetectorState::ACTIVE;
          offsetFrames_ = 0;
        }
        break;

      case DetectorState::REFRACTORY:
        binaryState_ = false;
        ++refractoryFrames_;
        if (releaseRequiredAfterTimeout_) {
          if (normalized < emg_parameters::kLow) {
            ++releaseFrames_;
          } else {
            releaseFrames_ = 0;
          }
          if (releaseFrames_ >=
              emg_parameters::kOffsetMs / static_cast<int>(kDecisionMs)) {
            releaseRequiredAfterTimeout_ = false;
          }
        }
        if (!releaseRequiredAfterTimeout_ &&
            refractoryFrames_ >= emg_parameters::kRefractoryMs /
                                     static_cast<int>(kDecisionMs) &&
            normalized < emg_parameters::kHigh) {
          state_ = DetectorState::REST;
          activeFrames_ = 0;
          releaseFrames_ = 0;
        }
        break;
    }
  }

  bool biteEvent() const { return biteEvent_; }

 private:
  void enterTimeout() {
    binaryState_ = false;
    state_ = DetectorState::REFRACTORY;
    refractoryFrames_ = 0;
    releaseFrames_ = 0;
    releaseRequiredAfterTimeout_ = true;
  }

  DetectorState state_ = DetectorState::REST;
  bool binaryState_ = false;
  bool biteEvent_ = false;
  int onsetPasses_ = 0;
  int onsetFailures_ = 0;
  int offsetFrames_ = 0;
  int activeFrames_ = 0;
  int refractoryFrames_ = 0;
  int releaseFrames_ = 0;
  bool releaseRequiredAfterTimeout_ = false;
};

}  // namespace

struct EMGDetector::Impl {
  struct ProcessingFrame {
    uint32_t timeMs;
    float envelope;
    bool qualityValid;
    bool biteEvent = false;
  };

  void begin() {
    if (started_) {
      return;
    }

    analogReadResolution(12);
    analogSetPinAttenuation(emg_parameters::kEmgPin, ADC_11db);
    systemStateStartedMs_ = millis();
    eventQueue_ = xQueueCreate(kEventQueueLength, sizeof(uint32_t));
    if (eventQueue_ == nullptr) {
      Serial.println("[EMG] Event queue failed");
      return;
    }

    const BaseType_t result = xTaskCreatePinnedToCore(
        sampleTask, "emg-envelope", 6144, this, 2, nullptr, 0);
    if (result != pdPASS) {
      Serial.println("[EMG] Sampling task failed");
      vQueueDelete(eventQueue_);
      eventQueue_ = nullptr;
      return;
    }
    started_ = true;
    Serial.println("[EMG] Detector started");
  }

  bool consumeTrigger() {
    uint32_t eventTimeMs = 0;
    return eventQueue_ != nullptr &&
           xQueueReceive(eventQueue_, &eventTimeMs, 0) == pdTRUE;
  }

  bool isReady() const { return ready_; }

  uint16_t latestRawAdc() const { return latestRawAdc_; }

  float latestNormalizedEnvelope() const {
    return latestNormalizedEnvelope_;
  }

  void requestRecalibration() {
    ready_ = false;
    manualRecalibrationRequested_ = true;
    Serial.println("[EMG] Manual recalibration requested");
  }

  static void sampleTask(void* argument) {
    static_cast<Impl*>(argument)->runSamplingTask();
  }

  void runSamplingTask() {
    TickType_t nextWakeTick = xTaskGetTickCount();
    uint32_t nextDeadlineUs = micros() + kSamplePeriodUs;
    size_t samplesInFrame = 0;
    EnvelopeSample signal = {};

    for (;;) {
      vTaskDelayUntil(&nextWakeTick, pdMS_TO_TICKS(2));
      const uint32_t nowUs = micros();
      const int32_t deadlineErrorUs =
          static_cast<int32_t>(nowUs - nextDeadlineUs);
      if (deadlineErrorUs >= static_cast<int32_t>(kSamplePeriodUs)) {
        const uint32_t skipped =
            static_cast<uint32_t>(deadlineErrorUs) / kSamplePeriodUs;
        nextDeadlineUs += skipped * kSamplePeriodUs;
      }
      nextDeadlineUs += kSamplePeriodUs;

      const int raw = analogRead(emg_parameters::kEmgPin);
      latestRawAdc_ = static_cast<uint16_t>(raw);
      qualityGuard_.add(raw);
      signal = extractor_.update(raw);
      ++samplesInFrame;
      if (samplesInFrame < kDecisionSamples) {
        continue;
      }
      samplesInFrame = 0;

      ProcessingFrame frame;
      frame.timeMs = nowUs / 1000UL;
      frame.envelope = signal.envelope;
      frame.qualityValid = qualityGuard_.finishFrame().valid;
      updateSystem(frame);
      if (frame.biteEvent &&
          xQueueSend(eventQueue_, &frame.timeMs, 0) != pdTRUE) {
        Serial.println("[EMG] Trigger event dropped");
      }
    }
  }

  void startCalibration(uint32_t nowMs) {
    systemState_ = DetectorSystemState::CALIBRATING;
    systemStateStartedMs_ = nowMs;
    calibrationAttemptStartedMs_ = nowMs;
    invalidFrameStreak_ = 0;
    recoveryGoodFrames_ = 0;
    qualityHoldoffFrames_ = 0;
    ready_ = false;
    calibrator_.reset();
    detector_.reset();
    Serial.println("[EMG] Calibrating");
  }

  void enterCalibrationFailed(uint32_t nowMs) {
    systemState_ = DetectorSystemState::CAL_FAILED;
    systemStateStartedMs_ = nowMs;
    ready_ = false;
    detector_.reset();
    Serial.println("[EMG] Calibration failed; automatic retry pending");
  }

  void enterSignalBad(uint32_t nowMs) {
    systemState_ = DetectorSystemState::SIGNAL_BAD;
    systemStateStartedMs_ = nowMs;
    recoveryGoodFrames_ = 0;
    ready_ = false;
    detector_.reset();
    Serial.println("[EMG] Signal quality bad");
  }

  void enterReady(uint32_t nowMs) {
    systemState_ = DetectorSystemState::READY;
    systemStateStartedMs_ = nowMs;
    invalidFrameStreak_ = 0;
    qualityHoldoffFrames_ = kQualityHoldoffFrames;
    detector_.reset();
    ready_ = true;
    Serial.println("[EMG] READY");
  }

  void updateSystem(ProcessingFrame& frame) {
    const uint32_t nowMs = frame.timeMs;
    frame.biteEvent = false;

    if (manualRecalibrationRequested_) {
      manualRecalibrationRequested_ = false;
      startCalibration(nowMs);
    }

    switch (systemState_) {
      case DetectorSystemState::SETTLING:
        detector_.reset();
        if (nowMs - systemStateStartedMs_ >=
            static_cast<uint32_t>(emg_parameters::kStartupIgnoreMs)) {
          startCalibration(nowMs);
        }
        break;

      case DetectorSystemState::CALIBRATING:
        detector_.reset();
        if (frame.qualityValid) {
          calibrator_.add(frame.envelope);
        }
        if (calibrator_.full()) {
          const CalibrationStats candidate = calibrator_.evaluate();
          if (candidate.valid) {
            restStats_ = candidate;
            enterReady(nowMs);
          } else if (nowMs - calibrationAttemptStartedMs_ <
                     kCalibrationMaxMs) {
            calibrator_.reset();
          } else {
            enterCalibrationFailed(nowMs);
          }
        } else if (nowMs - calibrationAttemptStartedMs_ >=
                   kCalibrationMaxMs) {
          enterCalibrationFailed(nowMs);
        }
        break;

      case DetectorSystemState::READY: {
        const float normalized =
            (frame.envelope - restStats_.center) / restStats_.scale;
        // Copy the already-computed value for the secondary-display UI.  This
        // assignment is observational; detector thresholds and state updates
        // below continue to use the original normalized local unchanged.
        latestNormalizedEnvelope_ = normalized;
        if (!frame.qualityValid) {
          ++invalidFrameStreak_;
          qualityHoldoffFrames_ = kQualityHoldoffFrames;
          if (invalidFrameStreak_ >= kSignalBadFrames) {
            enterSignalBad(nowMs);
          }
        } else {
          invalidFrameStreak_ = 0;
          if (qualityHoldoffFrames_ > 0) {
            --qualityHoldoffFrames_;
          } else {
            detector_.update(normalized);
            frame.biteEvent = detector_.biteEvent();
          }
        }
        break;
      }

      case DetectorSystemState::SIGNAL_BAD:
        detector_.reset();
        if (frame.qualityValid) {
          ++recoveryGoodFrames_;
          if (recoveryGoodFrames_ >= kSignalRecoveryFrames) {
            startCalibration(nowMs);
          }
        } else {
          recoveryGoodFrames_ = 0;
        }
        break;

      case DetectorSystemState::CAL_FAILED:
        detector_.reset();
        if (nowMs - systemStateStartedMs_ >= kCalibrationRetryMs) {
          startCalibration(nowMs);
        }
        break;
    }
  }

  QueueHandle_t eventQueue_ = nullptr;
  EnvelopeExtractor extractor_;
  SignalQualityGuard qualityGuard_;
  RestCalibrator calibrator_;
  DoubleThresholdDetector detector_;
  CalibrationStats restStats_;
  DetectorSystemState systemState_ = DetectorSystemState::SETTLING;
  uint32_t systemStateStartedMs_ = 0;
  uint32_t calibrationAttemptStartedMs_ = 0;
  int invalidFrameStreak_ = 0;
  int recoveryGoodFrames_ = 0;
  int qualityHoldoffFrames_ = 0;
  volatile bool ready_ = false;
  volatile uint16_t latestRawAdc_ = 0;
  volatile float latestNormalizedEnvelope_ = 0.0f;
  volatile bool manualRecalibrationRequested_ = false;
  bool started_ = false;
};

EMGDetector::EMGDetector() : impl_(new Impl()) {}

EMGDetector::~EMGDetector() { delete impl_; }

void EMGDetector::begin() { impl_->begin(); }

bool EMGDetector::consumeTrigger() { return impl_->consumeTrigger(); }

bool EMGDetector::isReady() const { return impl_->isReady(); }

uint16_t EMGDetector::latestRawAdc() const { return impl_->latestRawAdc(); }

float EMGDetector::latestNormalizedEnvelope() const {
  return impl_->latestNormalizedEnvelope();
}

void EMGDetector::requestRecalibration() { impl_->requestRecalibration(); }

}  // namespace EMG
