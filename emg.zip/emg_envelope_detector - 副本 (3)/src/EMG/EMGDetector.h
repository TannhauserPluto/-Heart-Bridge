#pragma once

#include <Arduino.h>

namespace EMG {

class EMGDetector {
 public:
  EMGDetector();
  ~EMGDetector();

  EMGDetector(const EMGDetector&) = delete;
  EMGDetector& operator=(const EMGDetector&) = delete;

  void begin();
  bool consumeTrigger();
  bool isReady() const;
  // Returns the most recent value acquired by the existing sampling task.
  // This is observational only; it does not invoke a second ADC conversion.
  uint16_t latestRawAdc() const;
  // Returns the existing detector-frame normalization
  // (envelope - rest baseline) / rest scale.  It is a display-only snapshot
  // and has no effect on thresholding or trigger decisions.
  float latestNormalizedEnvelope() const;
  void requestRecalibration();

 private:
  struct Impl;
  Impl* impl_;
};

}  // namespace EMG
