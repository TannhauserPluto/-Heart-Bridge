#include "EmgEventAdapter.h"

#include "Core/Config.h"

namespace EMG {

EmgEventAdapter::EmgEventAdapter(EMGDetector& detector) : detector_(detector) {}

void EmgEventAdapter::reset(uint32_t nowMs) {
  guardUntilMs_ = nowMs;
  discardPendingDetectorEvents();
}

bool EmgEventAdapter::update(uint32_t nowMs) {
  bool receivedEvent = false;
  while (detector_.consumeTrigger()) {
    receivedEvent = true;
  }

  // Always drain the detector queue.  During a short state-change guard
  // window, events belong to the prior page and must not advance the new one.
  return receivedEvent && reached(nowMs, guardUntilMs_);
}

void EmgEventAdapter::guardAfterStateChange(uint32_t nowMs) {
  guardUntilMs_ = nowMs + Core::Config::kStateInputGuardMs;
  discardPendingDetectorEvents();
}

void EmgEventAdapter::discardPendingDetectorEvents() {
  while (detector_.consumeTrigger()) {
  }
}

bool EmgEventAdapter::reached(uint32_t nowMs, uint32_t targetMs) {
  return static_cast<int32_t>(nowMs - targetMs) >= 0;
}

}  // namespace EMG
