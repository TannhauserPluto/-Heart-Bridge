#pragma once

#include <Arduino.h>

#include "EMG/EMGDetector.h"

namespace EMG {

// Converts the detector's queued action events into application events and
// discards residual events around state changes.  It observes only the
// existing detector API and never changes detector thresholds or timing.
class EmgEventAdapter {
 public:
  explicit EmgEventAdapter(EMGDetector& detector);

  void reset(uint32_t nowMs);
  bool update(uint32_t nowMs);
  void guardAfterStateChange(uint32_t nowMs);

 private:
  void discardPendingDetectorEvents();
  static bool reached(uint32_t nowMs, uint32_t targetMs);

  EMGDetector& detector_;
  uint32_t guardUntilMs_ = 0;
};

}  // namespace EMG
