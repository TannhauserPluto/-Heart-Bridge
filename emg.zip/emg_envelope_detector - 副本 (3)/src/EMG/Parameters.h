#pragma once

// Parameters used by the integrated HeartBridge EMG detector.
namespace emg_parameters {
constexpr const char *kStatus = "PROVISIONAL_DIRECT_USE_EXPERIMENT";
constexpr int kSampleRateHz = 500;
constexpr int kEmgPin = 3;
constexpr int kStartupIgnoreMs = 7000;
constexpr int kRestCalibrationMs = 5000;
constexpr int kEnvelopeMs = 50;
constexpr int kDecisionMs = 20;
constexpr float kHigh = 6.0f;
constexpr float kLow = 3.0f;
constexpr int kOnsetMs = 80;
constexpr int kOffsetMs = 140;
constexpr int kAllowedFailureFrames = 2;
constexpr int kRefractoryMs = 400;
constexpr int kTimeoutMs = 1800;
}  // namespace emg_parameters
