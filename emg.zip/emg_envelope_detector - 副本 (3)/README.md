# 心桥（HeartBridge）

基于 ESP32-S3 / M5Cardputer 的辅助沟通主程序。它将咬肌 EMG 与 HS-S71-PY 微动输入转换为确认操作，在主屏上完成需求扫描与确认，并通过串口输出已确认的本地请求记录。

## 构建

```powershell
pio run -e heartbridge
pio run -e heartbridge -t buildfs
```

固件和语音文件系统需要分别烧录：

```powershell
pio run -e heartbridge -t upload
pio run -e heartbridge -t uploadfs
```

程序入口为 `src/main.cpp`，应用协调逻辑位于 `src/App/Application.cpp`。

## 目录

- `src/App`：应用编排与输入保护
- `src/EMG`：EMG 采样、校准与触发检测
- `src/Interaction`：需求选择状态机
- `src/Display`：主屏与两个副屏显示
- `src/Input`：HS-S71-PY 微动传感器
- `src/Communication`：本地确认请求记录
- `src/Core`：硬件、SPI 总线和时序基础设施
- `src/Audio`：本地 WAV 的非阻塞播放与页面语音映射
- `audio/source`：edge-tts 原始 MP3
- `audio/wav`：16 kHz、16-bit、单声道 PCM WAV 验收资产
- `data/voice`：随 LittleFS 烧录到设备的 WAV
- `tools/generate_tts.py`：可重复执行的 TTS、转换、时长验证和 manifest 生成脚本

根目录的 PDF 与文本文件为连接、屏幕和模块的硬件参考资料。

## 重新生成语音

开发环境依赖可安装到工程本地目录：

```powershell
python -m pip install --target tools/.packages edge-tts miniaudio
```

联网重新生成全部语音、转换 WAV、读取真实时长、检查页面时间并同步
LittleFS 资产：

```powershell
python tools/generate_tts.py
```

仅使用现有 MP3 重新转换和验证，不访问网络：

```powershell
python tools/generate_tts.py --skip-tts
```

验收结果位于 `audio/audio_manifest.csv` 和
`audio/audio_manifest.json`。设备运行时不使用 Wi-Fi，也不调用任何在线 TTS。

当前语音使用 `zh-CN-XiaoxiaoNeural`。该服务没有把它标记为老人音色；选择依据是
实时音色元数据中的 `Warm`，并使用 `pitch=-8Hz`、通常 `rate=-5%` 的轻微调整。
呼叫页因固定为 1500 ms，脚本自动改用 `rate=+15%`，保证 300 ms 以上余量。

## 音频实现

WAV 保存在 2 MB LittleFS 分区中，播放时只将当前文件载入 RAM。`AudioManager`
使用 M5Unified 的后台 I2S/DMA 任务，固定到 Core 1；EMG 的 500 Hz 任务继续独立运行在
Core 0。页面或需求真正变化时才触发一次语音。提前离开页面时先异步停止旧语音，
新页面绘制完成后再播放新语音。

Cardputer Adv 的 ES8311 通过专用的内部 I2C1 初始化序列进行配置，随后进行寄存器读回
校验。音频模块不调用整机 `M5.begin()`，因此不会初始化或接管 Cardputer 内屏。
主副屏先完成控制器初始化，随后 ES8311 才短暂复用 GPIO8/9；配置完成后立即释放 I2C
并恢复全部外部显示控制脚。运行期音频只使用 GPIO41/42/43。
自定义分区表中的文件系统标签为 `littlefs`，程序显式按该标签挂载，不能使用 Arduino
默认的 `spiffs` 标签。
M5Unified 会对主音量做平方缩放，因此用户设定的约 30% 输出电平对应
`kVoiceVolume = 140`，而不是线性换算得到的 77。启动约 30 秒后串口会
输出一次 `[AUDIO] DIAG`，用于确认 codec、I2S 任务、音量和引脚配置，不播放任何
启动或校准提示音。
